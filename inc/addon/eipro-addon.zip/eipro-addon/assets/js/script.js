jQuery(document).ready(function($) {

    // PRODUCT TAB
    $('.eipro-tabs-nav-link').on('click', function(event) {

        // Prevent default behavior
        event.preventDefault();

        // Get the tab content
        var tabContent = $(this).closest('.eipro-tabs-widget').find('.eipro-tabs-tab');

        // Get the index of the clicked tab link
        var tabIndex = $(this).closest('.eipro-tabs-nav-item').index();

        // Remove the active class from all tab links and content
        $(this).closest('.eipro-tabs-nav').find('.eipro-tabs-nav-item').removeClass('eipro-tab-active');
        tabContent.fadeOut(1);

        // Add the active class to the clicked tab link and content
        $(this).closest('.eipro-tabs-nav-item').addClass('eipro-tab-active');
        tabContent.eq(tabIndex).fadeIn(600);

        // Set the URL hash
        location.hash = $(this).attr("href");

        var space_content = $(".hide-p-sidebar .content.c-fullwidth .main-navigation").height();
        var tabs_wrap = $(".eipro-tabs-wrap").height();
        if ($(window).width() < 1025) {
          $("html").css("scroll-padding-top", space_content+tabs_wrap+80);
        }

    });
    // PRODUCT TAB END

    // PRODUCT DESCRIPTION
    $('.eipro-d-nav-link').on('click', function(event) {

        // Prevent default behavior
        event.preventDefault();

        // Get the tab content
        var tabContent = $(this).closest('.eipro-product-desc-widget').find('.eipro-d-tab-tab');

        // Get the index of the clicked tab link
        var tabIndex = $(this).closest('.eipro-d-nav-item').index();

        // Remove the active class from all tab links and content
        $(this).closest('.eipro-d-nav').find('.eipro-d-nav-item').removeClass('eipro-d-active');
        tabContent.fadeOut(1);

        // Add the active class to the clicked tab link and content
        $(this).closest('.eipro-d-nav-item').addClass('eipro-d-active');
        tabContent.eq(tabIndex).fadeIn(600);

        // Set the URL hash
        location.hash = $(this).attr("href");

        var space_content = $(".hide-p-sidebar .content.c-fullwidth .main-navigation").height();
        var d_tab_wrap = $(".eipro-d-tab-wrap").height();
        //$("html").css("scroll-padding-top", space_content+140);
        $("html").css("scroll-padding-top", space_content+d_tab_wrap+75);

        // var d_tab_wrap = $(".eipro-d-tab-wrap").height();
        // if ($(window).width() < 1025) {
        //   $("html").css("scroll-padding-top", space_content+d_tab_wrap+105);
        // } else if ($(window).width() < 768) {
        //   $("html").css("scroll-padding-top", space_content+d_tab_wrap);
        // } else {
        //   $("html").css("scroll-padding-top", space_content+d_tab_wrap+80);
        // }

        // FAQ
        var faq_first = $('.eipro-d-faq-list:first-child .eipro-d-faq-desc.desc-active');
        if ($(tabContent.eq(tabIndex)).find('.eipro-d-faq-list:first-child .eipro-d-faq-desc').filter(':visible').hasClass('desc-active')) {
          var faq_desc = $(tabContent.eq(tabIndex)).find(faq_first).filter(':visible').height();
          $(tabContent.eq(tabIndex)).find(faq_first).css("height", faq_desc);
        }

    });

    var space_content = $(".hide-p-sidebar .content.c-fullwidth .main-navigation").height();
    if ($(window).width() < 1025) {
      $(".eipro-d-tab-wrap").css("top", space_content+25);
    } else {
      $(".eipro-d-tab-wrap").css("top", space_content+1);
      $(".eipro-tabs-wrap.e-tabs-sticky, .eipro-price-widget").css("top", space_content+50);
    }
    // PRODUCT DESCRIPTION END

    // TESTIMONIAL
    $('.eipro-testimonial').slick({
      arrows: false,
      autoplaySpeed: 3300,
      speed: 800,
      responsive: [
        {
          breakpoint: 1025,
          settings: {
            slidesToShow: 2,
            slidesToScroll: 1
          }
        },
        {
          breakpoint: 767,
          settings: {
            slidesToShow: 1,
            slidesToScroll: 1
          }
        }
      ]
    });
    // TESTIMONIAL END

    // PRICE
    $(".dropbtn").click(function() {
        $(this).next(".dropdown-content").toggleClass("c-active");
    });
    
    $(".license-option").click(function() {
        var label = $(this).data("label");
        $("#licenseButton").text(label);
        
        $(".license-option").removeClass("license-selected");
        $(this).addClass("license-selected");
        
        var licenseId = $(this).data("license");
        $(".license-description").hide();
        $("#license" + licenseId).show();

        $(".dropdown-content").removeClass("c-active");
    });

    $(".c-btn-price-sticky").click(function() {
      $(".eipro-price-widget-wrap, .eipro-business .epw-close-overlay, .eipro-business .epw-overlay-backdrop").addClass("epw-active");
      $(".eipro-business footer.c-footer").removeClass("epf-active");
      $(this).hide();
    });
    $(".eipro-business .epw-close, .eipro-business .epw-close-overlay, .eipro-business .epw-overlay-backdrop").click(function() {
      $(".eipro-price-widget-wrap, .eipro-business .epw-close-overlay, .eipro-business .epw-overlay-backdrop").removeClass("epw-active");
      $(".eipro-business footer.c-footer").addClass("epf-active");
      $(".c-btn-price-sticky").show();
    });
    // PRICE END

});

document.addEventListener("DOMContentLoaded", function() {

// PRODUCT FAQ
var faqTitles = document.querySelectorAll('.eipro-d-faq-title');
var faqDescs = document.querySelectorAll('.eipro-d-faq-desc');

// var firstDesc = faqDescs[0];
// firstDesc.style.height = firstDesc.scrollHeight + 'px';

faqTitles.forEach(function(title) {
  title.addEventListener('click', function() {
    var activeTitle = document.querySelector('.eipro-d-faq-active');
    var desc = this.nextElementSibling;

    if (activeTitle !== this) {
      if (activeTitle) {
        activeTitle.classList.remove('eipro-d-faq-active');
      }
      this.classList.add('eipro-d-faq-active');
    } else {
      this.classList.remove('eipro-d-faq-active');
    }

    faqDescs.forEach(function(item) {
      if (item !== desc) {
        item.style.height = '0px';
        item.classList.remove('desc-active');
      }
    });

    if (desc.classList.contains('desc-active')) {
      desc.style.height = '0px';
      desc.classList.remove('desc-active');
    } else {
      var height = desc.scrollHeight;
      desc.style.height = height + 'px';
      desc.classList.add('desc-active');
    }
  });
});
// PRODUCT FAQ END

// PRODUCT TAB STICKY
const scrollWrapper = document.querySelector(".eipro-d-tab-wrap>div, .eipro-tabs-wrap>div>div");
const navLinks = document.querySelectorAll(".eipro-d-nav-link, .eipro-tabs-nav-link");
const arrowLeft = document.querySelector(".eipro-d-nav-scroll-icon-left");
const arrowRight = document.querySelector(".eipro-d-nav-scroll-icon-right");
const graduatedfilterleft = document.querySelector(".eipro-d-nav-graduated-filter-left");
const graduatedfilterright = document.querySelector(".eipro-d-nav-graduated-filter-right");

// Add active class to nav link when section is in view
const options = {
rootMargin: "-50px 0px -50px 0px",
threshold: 0.7
};

const observer = new IntersectionObserver(function(entries, observer) {
entries.forEach(entry => {
  if (entry.isIntersecting) {
    const targetId = entry.target.id;
    const targetLink = document.querySelector('.eipro-d-nav-link[href="#${targetId}"], .eipro-tabs-nav-link[href="#${targetId}"]');

    // Shift the scroll menu if the active link is too wide
    const scrollWrapperWidth = scrollWrapper.offsetWidth;
    const targetLinkOffsetLeft = targetLink.offsetLeft;
    const targetLinkOffsetRight = targetLinkOffsetLeft + targetLink.offsetWidth;
    const scrollWrapperOffsetLeft = scrollWrapper.offsetLeft;
    const scrollWrapperOffsetRight = scrollWrapperOffsetLeft + scrollWrapperWidth;

    // Check if the target link is outside of the visible area to the left
    if (targetLinkOffsetLeft < scrollWrapperOffsetLeft) {
      scrollWrapper.scrollTo({
        left: targetLinkOffsetLeft,
        behavior: "smooth"
      });
    }

    // Check if the target link is outside of the visible area to the right
    if (targetLinkOffsetRight > scrollWrapperOffsetRight) {
      scrollWrapper.scrollTo({
        left: targetLinkOffsetRight - scrollWrapperWidth,
        behavior: "smooth"
      });
    }

    // is the last section and the target link is too wide, shift the scroll menu to the left
    if (targetId === sections[sections.length - 1].id && targetLinkOffsetRight > scrollWrapperOffsetRight) {
      scrollWrapper.scrollTo({
        left: targetLinkOffsetLeft - scrollWrapperWidth + targetLink.offsetWidth,
        behavior: "smooth"
      });
    }
  }
});

}, options);

if (arrowLeft) {
// Arrow slider
arrowLeft.addEventListener("click", function() {
scrollWrapper.scrollBy({
left: -150,
behavior: "smooth"
});
});

arrowRight.addEventListener("click", function() {
scrollWrapper.scrollBy({
left: 150,
behavior: "smooth"
});
});

// Hide/show arrow slider
const toggleArrowSlider = function() {
if (scrollWrapper.scrollLeft === 0) {
arrowLeft.style.display = "none";
graduatedfilterleft.style.display = "none";
} else {
arrowLeft.style.display = "block";
graduatedfilterleft.style.display = "block";
}
if (scrollWrapper.scrollLeft + scrollWrapper.clientWidth >= scrollWrapper.scrollWidth) {
  arrowRight.style.display = "none";
  graduatedfilterright.style.display = "none";
} else {
  arrowRight.style.display = "block";
  graduatedfilterright.style.display = "block";
}
};

toggleArrowSlider();

scrollWrapper.addEventListener("scroll", toggleArrowSlider);
}

// PRODUCT TAB STICKY END

});


// Replace URL HASH / (Delete)
function removeLocationHash(){
    var noHashURL = window.location.href.replace(/#.*$/, '');
    window.history.replaceState('', document.title, noHashURL) 
}
window.addEventListener("popstate", function(event){
    removeLocationHash();
});
window.addEventListener("hashchange", function(event){
    event.preventDefault();
    removeLocationHash();
});
window.addEventListener("load", function(){
    removeLocationHash();
});
// Replace URL HASH / (Delete) End

// Move Element
const me_price = document.querySelector('.eipro-business .eipro-price-widget-wrap .c-btn-price-sticky');
const me_footer = document.querySelector('.eipro-business footer.c-footer');
const chat_wa = document.querySelector('.eipro-business .chat-wa');

if (me_price) {
  me_footer.insertAdjacentElement('afterend', me_price);
  me_footer.classList.add('epf-active');
  if (chat_wa) {
    chat_wa.classList.add('epf-active');
  }
}
// Move Element END
