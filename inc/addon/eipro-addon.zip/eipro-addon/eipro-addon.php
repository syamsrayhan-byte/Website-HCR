<?php
/**
 * Plugin Name: eiPro Addon
 * Description: Unleash your creativity with eiPro Addon for Elementor.
 * Plugin URI:  https://www.eitheme.com/
 * Version:     1.1.2
 * Author:      Erik
 * Author URI:  https://erikse.com/
 * Text Domain: eipro-addon
 */

require 'upt/upt.php';
use YahnisElsts\PluginUpdateChecker\v5\PucFactory;
$eiupt=PucFactory::buildUpdateChecker('https://updater.eitheme.com/update/eipro-addon',__FILE__,'eipro-addon');

if(!defined('ABSPATH')){exit;}if(!defined('WPINC')){die;}

define('EIPRO_ADDON_VERSION','1.1.2');
define('EIPRO_PARENT_THEME', 'eiPro Master');

/**
 * Register eiPro Widget.
 *
 * Include widget file and register widget class.
 *
 * @since 1.0.0
 * @param \Elementor\Widgets_Manager $widgets_manager Elementor widgets manager.
 * @return void
 */
function register_eipro_widget( $widgets_manager ) {

    require_once( __DIR__ . '/widgets/product-tab.php' );
    require_once( __DIR__ . '/widgets/testimonial-slider.php' );
    require_once( __DIR__ . '/widgets/price.php' );
    require_once( __DIR__ . '/widgets/product-description.php' );

    $widgets_manager->register( new \Elementor_Product_Tab_Widget() );
    $widgets_manager->register( new \Elementor_Testimonial_Slider_Widget() );
    $widgets_manager->register( new \Elementor_Price_Widget() );
    $widgets_manager->register( new \Elementor_Product_Description_Widget() );

}
add_action( 'elementor/widgets/register', 'register_eipro_widget' );

function eipro_addon_scripts() {
    
    $layout_set = get_theme_mod('layout_set');
    $minify_css_js = get_theme_mod( 'setting_minify_css_js' );
    if ( $minify_css_js == true ) {
        wp_enqueue_style( 'main-style', plugins_url( '/assets/css/style.min.css', __FILE__ ), array(), time() );
    } else {
        wp_enqueue_style( 'main-style', plugins_url( '/assets/css/style.css', __FILE__ ), array(), time() );
    }

    wp_enqueue_script( 'jquery-3.5.1', 'https://code.jquery.com/jquery-3.5.1.min.js', array( 'jquery' ), '3.5.1', true );
    
    if($layout_set == 'lbusiness') {
       if ( $minify_css_js == true ) {
            wp_enqueue_script( 'main-script', plugins_url( '/assets/js/script.min.js', __FILE__ ), array(), time(), true );
       } else {
            wp_enqueue_script( 'main-script', plugins_url( '/assets/js/script.js', __FILE__ ), array(), time(), true );
       }
    }

    // Move jQuery Core and jQuery Migrate to footer
    wp_scripts()->add_data( 'jquery', 'group', 1 );
    wp_scripts()->add_data( 'jquery-core', 'group', 1 );
    wp_scripts()->add_data( 'jquery-migrate', 'group', 1 );

}
add_action( 'wp_enqueue_scripts', 'eipro_addon_scripts' );
function my_custom_editor_styles() { ?> <style type="text/css"> .elementor-control-product .elementor-button-wrapper, .elementor-control-testimonial_content .elementor-button-wrapper, .elementor-control-changelog_content .elementor-button-wrapper, .elementor-control-faq_content .elementor-button-wrapper, .elementor-control-tab_list_item .elementor-button-wrapper { display: none !important; } </style> <?php } add_action( 'elementor/editor/after_enqueue_styles', 'my_custom_editor_styles' ); function ei_init() { global $eiaddon; $resources = [ wp_get_theme()->name ]; if (wp_get_theme()->parent_theme) { $resources[] = wp_get_theme()->parent_theme; } $eiaddon = in_array(EIPRO_PARENT_THEME, $resources) && in_array(plugin_basename(__FILE__), get_option('active_plugins', array())); } add_action('plugins_loaded', 'ei_init', 10); function ei_load() { global $eiaddon; $eiaddon ? null : update_option('active_plugins', array_diff(get_option('active_plugins'), array(plugin_basename(__FILE__)))); } add_action('plugins_loaded', 'ei_load', 11); function ei_pntf($ei_transient) { global $eiaddon; $ei_sbl = array('eipro-addon'); $ei_insp = get_plugins(); foreach ($ei_insp as $ei_ins_path => $ei_ins_info) { $ei_ins_slug = dirname($ei_ins_path); if (in_array($ei_ins_slug, $ei_sbl)) { if (!$eiaddon && isset($ei_transient->response[$ei_ins_path])) { unset($ei_transient->response[$ei_ins_path]); } } } return $ei_transient; } add_filter('site_transient_update_plugins', 'ei_pntf'); function eipro_customize_script() { ?> <script type="text/javascript"> jQuery('.c-direct-wa').click(c_direct_wa); function c_direct_wa() { var phone_number = <?php echo json_encode(get_theme_mod('phone_number_wa')); ?>; var sitename = "<?php bloginfo('name'); ?>"; var title = <?php echo json_encode(get_the_title()); ?>; var url = <?php echo json_encode(get_permalink()); ?>; var package = jQuery('.eipro-price-widget .dropbtn').text(); var showprice = jQuery('.eipro-price-widget .license-description .c-price>span:last-child').filter(function() { return jQuery(this).is(':visible'); }); var price = showprice.html(); var message_wa = <?php echo json_encode(get_theme_mod('message_order_wa')); ?>; var message = message_wa.split('{sitename}').join(sitename).replace('{title}', title).replace('{url}', url).replace('{package}', package).replace('{price}', price); var encoded_message = encodeURIComponent(message); var url_wa = 'https://web.whatsapp.com/send?phone=' + phone_number + '&text=' + encoded_message + '&pre-filled=true'; if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) { url_wa = 'whatsapp://send/?phone=' + phone_number + '&text=' + encoded_message; } var w = 960, h = 540, left = Number((screen.width / 2) - (w / 2)), tops = Number((screen.height / 2) - (h / 2)), popupWindow = window.open(url_wa, '', 'toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=yes, resizable=1, copyhistory=no, width=' + w + ', height=' + h + ', top=' + tops + ', left=' + left); popupWindow.focus(); return false; }

        // ei more product
        function loadMoreItems(event) {
            const eiproList = event.currentTarget.parentElement;
            
            if (eiproList) {
              const limit = parseInt(eiproList.getAttribute('data-load-limit'));
              const items = Array.from(eiproList.querySelectorAll('.eipro-list-item')).filter(item => item.style.display === 'none');
              const itemsToShow = items.slice(0, limit);

              itemsToShow.forEach(item => (item.style.display = 'block'));

              if (items.length <= limit) {
                const loadMoreButton = eiproList.querySelector('.ei-more-product');
                if (loadMoreButton) {
                  loadMoreButton.style.display = 'none';
                }
              }

              document.querySelectorAll('.eipro-list').forEach(list => {
                if (list !== eiproList) {
                  const loadMoreButton = list.querySelector('.ei-more-product');
                  if (loadMoreButton) {
                    const otherItems = Array.from(list.querySelectorAll('.eipro-list-item'));
                    otherItems.forEach((item, index) => (item.style.display = index >= limit ? 'none' : 'block'));
                    loadMoreButton.style.display = otherItems.length <= limit ? 'none' : 'block';
                  }
                }
              });
            }
          }

          document.querySelectorAll('.ei-more-product').forEach(button => button.addEventListener('click', loadMoreItems));

          document.querySelectorAll('.eipro-list').forEach(eiproList => {
            const limit = parseInt(eiproList.getAttribute('data-load-limit'));
            const items = Array.from(eiproList.querySelectorAll('.eipro-list-item'));
            items.forEach((item, index) => (item.style.display = index >= limit ? 'none' : 'block'));

            if (items.length <= limit) {
              const loadMoreButton = eiproList.querySelector('.ei-more-product');
              if (loadMoreButton) {
                loadMoreButton.style.display = 'none';
              }
            }
          });
        // ei more product - end
    </script>

<?php }
add_action( 'after_setup_theme', function(){
add_action('wp_footer', 'eipro_customize_script');
} );
