=== eipro-addon ===

Requires at least: 6.6
Tested up to: 6.8
Stable tag: 6.7
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

Unleash your creativity with eiPro Addon for Elementor.

== Changelog ==

= 1.1.2 - Jul 03, 2025 =
* Minor update

= 1.1.1 - Jun 10, 2025 =
* Improved: Elementor compatibility

= 1.1.0 - Jan 25, 2025 =
* Improved: Elementor compatibility

= 1.0.9 - Sep 02, 2024 =
* Fix: Icons in product listing

= 1.0.8 - Aug 28, 2024 =
* Improved: Elementor compatibility

= 1.0.7 - Apr 28, 2024 =
* Major Update

= (1.0.5 - 1.0.6) - Nov 19, 2023 =
* Minor update

= 1.0.4 - Nov 08, 2023 =
* Minor update

= 1.0.3 - Nov 06, 2023 =
* Fix margin-left in the .eipro-tabs-sticky
* Fix sticky in the .eipro-price-widget
* New: Icons in product listing
* New: Load more button

= 1.0.2 - Jun 25, 2023 =
* Fix Sticky Header in Safari ISSUE

= 1.0.1 - May 16, 2023 =
* Direct WhatsApp Chat
* Order via WhatsApp

= 1.0.0 - May 07, 2023 =
* Initial release
