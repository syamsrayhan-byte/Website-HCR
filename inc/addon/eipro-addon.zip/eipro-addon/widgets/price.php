<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

class Elementor_Price_Widget extends \Elementor\Widget_Base {

    public function get_name() {
        return 'eipro-price';
    }

    public function get_title() {
        return __( 'Price - eiPro', 'eipro-addon' );
    }

    public function get_icon() {
        return 'eicon-price-table';
    }

    public function get_categories() {
        return [ 'general' ];
    }

    public function get_keywords() {
        return [ 'price', 'product' ];
    }


    protected function _register_controls() {

        $this->start_controls_section(
            'section_tabs',
            [
                'label' => esc_html__( 'Content', 'eipro-addon' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        /* Start repeater */

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'tab_title',
            [
                'label' => esc_html__( 'Title', 'eipro-addon' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'placeholder' => esc_html__( 'Single Site License', 'eipro-addon' ),
                'default' => esc_html__( 'Single Site License', 'eipro-addon' ),
                'label_block' => true,
                'dynamic' => [
                    'active' => true,
                ],
            ]
        );

        $repeater->add_control(
            'tab_subtitle',
            [
                'label' => esc_html__( 'Description', 'eipro-addon' ),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'placeholder' => esc_html__( 'Description', 'eipro-addon' ),
                'default' => esc_html__( 'Lorem ipsum dolor amet labore magna aliqua:', 'eipro-addon' ),
                'label_block' => true,
                'dynamic' => [
                    'active' => true,
                ],
            ]
        );

        $repeater->add_control(
            'tab_regular_price',
            [
                'label' => esc_html__( 'Regular Price', 'eipro-addon' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'placeholder' => esc_html__( 'Rp 999', 'eipro-addon' ),
                'default' => esc_html__( 'Rp 999', 'eipro-addon' ),
                'label_block' => true,
                'dynamic' => [
                    'active' => true,
                ],
            ]
        );

        $repeater->add_control(
            'tab_sale_price',
            [
                'label' => esc_html__( 'Sale Price', 'eipro-addon' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'placeholder' => esc_html__( 'Rp 888', 'eipro-addon' ),
                'default' => esc_html__( 'Rp 888', 'eipro-addon' ),
                'label_block' => true,
                'dynamic' => [
                    'active' => true,
                ],
            ]
        );

        $repeater->add_control(
            'tab_link_text',
            [
                'label' => esc_html__( 'Link Text', 'eipro-addon' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'placeholder' => esc_html__( 'Purchase Now', 'eipro-addon' ),
                'default' => esc_html__( 'Purchase Now', 'eipro-addon' ),
                'label_block' => true,
                'dynamic' => [
                    'active' => true,
                ],
            ]
        );

        $repeater->add_control(
            'type_link',
            [
                'label' => esc_html__( 'Direct', 'eipro-addon' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'link',
                'options' => [
                    'link'  => esc_html__( 'Link', 'eipro-addon' ),
                    'whatsapp' => esc_html__( 'WhatsApp', 'eipro-addon' ),
                ],
            ]
        );

        $repeater->add_control(
            'tab_url',
            [
                'label' => esc_html__( 'URL', 'eipro-addon' ),
                'type' => \Elementor\Controls_Manager::URL,
                'placeholder' => __( 'https://example.com', 'eipro-addon' ),
                'default' => [
                    'url' => '',
                    'is_external' => false,
                    'nofollow' => false,
                ],
                'condition' => [
                    'type_link' => 'link',
                ],
                'dynamic' => [
                    'active' => true,
                ],
            ]
        );

        $repeater->add_control(
            'tab_list_item',
            [
                'label' => esc_html__( 'List Items', 'eipro-addon' ),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => [
                    [
                        'name' => 'list_item_text',
                        'label' => esc_html__( 'Text', 'eipro-addon' ),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'default' => 'List Item',
                        'label_block' => true,
                        'dynamic' => [
                            'active' => true,
                        ],
                    ],
                ],
                'default' => [
                    [
                        'list_item_text' => 'List Item',
                    ],
                ],
                'title_field' => '{{{ list_item_text }}}',
            ]
        );

        $this->add_control(
            'tabs',
            [
                'label' => esc_html__( 'Tabs', 'eipro-addon' ),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),           /* Use our repeater */
                'default' => [
                    [
                        'tab_title' => esc_html__( 'Single Site License', 'eipro-addon' ),
                        'tab_subtitle' => esc_html__( 'Lorem ipsum dolor amet labore magna aliqua:', 'eipro-addon' ),
                        'tab_regular_price' => esc_html__( 'Rp 999', 'eipro-addon' ),
                        'tab_link_text' => esc_html__( 'Purchase Now', 'eipro-addon' ),
                    ],
                    [
                        'tab_title' => esc_html__( '2 Sites License', 'eipro-addon' ),
                        'tab_subtitle' => esc_html__( 'Lorem ipsum dolor amet labore magna aliqua:', 'eipro-addon' ),
                        'tab_regular_price' => esc_html__( 'Rp 999', 'eipro-addon' ),
                        'tab_link_text' => esc_html__( 'Purchase Now', 'eipro-addon' ),
                    ],
                    [
                        'tab_title' => esc_html__( '5 Sites License', 'eipro-addon' ),
                        'tab_subtitle' => esc_html__( 'Lorem ipsum dolor amet labore magna aliqua:', 'eipro-addon' ),
                        'tab_regular_price' => esc_html__( 'Rp 999', 'eipro-addon' ),
                        'tab_link_text' => esc_html__( 'Purchase Now', 'eipro-addon' ),
                    ],
                ],
                'title_field' => '{{{ tab_title }}}',
            ]
        );


        $this->end_controls_section();


        $this->start_controls_section(
            'section_cta_options',
            [
                'label' => esc_html__( 'Call To Action Button - Mobile', 'eipro-addon' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'cta_link_text',
            [
                'label' => esc_html__( 'Link Text', 'eipro-addon' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'placeholder' => esc_html__( 'Purchase Now', 'eipro-addon' ),
                'default' => esc_html__( 'Purchase Now', 'eipro-addon' ),
                'label_block' => true,
                'dynamic' => [
                    'active' => true,
                ],
            ]
        );

        $this->end_controls_section();

    }

    protected function render() {

        $settings = $this->get_settings_for_display();
        ?>

        <div class="eipro-price-widget-wrap">
        <div class="eipro-price-widget">

            <span class="epw-close">
                  <span><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Capa_1" x="0px" y="0px" viewBox="0 0 512.021 512.021" style="enable-background:new 0 0 512.021 512.021;" xml:space="preserve" width="512" height="512">
                        <g>
                              <path d="M301.258,256.01L502.645,54.645c12.501-12.501,12.501-32.769,0-45.269c-12.501-12.501-32.769-12.501-45.269,0l0,0   L256.01,210.762L54.645,9.376c-12.501-12.501-32.769-12.501-45.269,0s-12.501,32.769,0,45.269L210.762,256.01L9.376,457.376   c-12.501,12.501-12.501,32.769,0,45.269s32.769,12.501,45.269,0L256.01,301.258l201.365,201.387   c12.501,12.501,32.769,12.501,45.269,0c12.501-12.501,12.501-32.769,0-45.269L301.258,256.01z"></path>
                        </g>
                  </svg></span>
            </span>
            <div class="eipro-price-wrap">
                <div class="c-dropdown">
                    <button id="licenseButton" class="dropbtn">
                        <?php
                        foreach ( $settings['tabs'] as $index => $tab ){
                            if ( $index === 0 ){
                                echo esc_html( $tab['tab_title'] );
                            }
                        }
                        ?>
                    </button>
                    <div class="dropdown-content">

                        <?php
                        $i=0;
                        foreach ( $settings['tabs'] as $index => $tab ) :
                        $i++
                        ?>
                            <div class="license-option <?php if ( $index === 0 ) : ?> license-selected<?php endif; ?>" data-license="<?= $i;?>" data-label="<?= $tab['tab_title']; ?>">
                                <?php echo esc_html( $tab['tab_title'] ); ?>
                            </div>
                        <?php endforeach; ?>

                    </div>
                </div>
            </div>

            <div class="eipro-price-content">

            <?php
            $i=0;
            foreach ( $settings['tabs'] as $index => $tab ) :
            $i++
            ?>
                <div id="license<?= $i;?>" class="license-description" <?php if ( $index === 0 ){}else{echo 'style="display:none"';} ?>>
                    <?php
                    if ( $tab['tab_subtitle'] ) {
                        echo '<p>'. esc_html( $tab['tab_subtitle'] ) .'</p>';
                    }
                    if ( $tab['tab_list_item'] ) {
                        echo '<ul class="eipro-list-item">';
                        foreach ( $tab['tab_list_item'] as $tab_list_item ) :
                            echo '<li>'. esc_html( $tab_list_item['list_item_text'] ) .'</li>';
                        endforeach;
                        echo '</ul>';
                    }
                    ?>
                    <?php if ( $tab['tab_regular_price'] ) { ?>
                    <div class="c-price">
                        <span<?php if ( $tab['tab_sale_price'] ) { echo ' class="c-regular-price"'; } ?>><?= esc_html( $tab['tab_regular_price'] ); ?></span>
                        <?php
                        if ( $tab['tab_sale_price'] ) {
                            echo '<span>'. esc_html( $tab['tab_sale_price'] ) .'</span>';
                        }
                        ?>
                    </div>
                    <?php } ?>

                    <?php
                    if ( $tab['type_link'] === 'whatsapp' ) {
                        echo '<div class="c-btn c-direct-wa"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" xml:space="preserve"><path d="M20.5 3.5A12 12 0 0 0 12 0 12 12 0 0 0 0 11.9a12 12 0 0 0 1.6 6L.1 24l6.3-1.7a12 12 0 0 0 5.6 1.5 12 12 0 0 0 12-11.9 12 12 0 0 0-3.5-8.4M12 21.8a10 10 0 0 1-5-1.4l-.4-.2-3.8 1 1-3.7-.2-.3a10 10 0 0 1-1.5-5.3 9.9 9.9 0 0 1 16.8-7 10 10 0 0 1 3 7 10 10 0 0 1-10 9.9m5.4-7.4-2-1q-.4-.1-.7.2l-1 1.1q-.2.3-.6.1-.6 0-2.4-1.5-1.4-1.4-1.7-2c-.3-.6 0-.5.2-.6l.4-.6.3-.5v-.5L9 7q-.3-.7-.6-.5h-.6q-.3-.1-.8.4c-.5.5-1 1-1 2.5 0 1.4 1 2.8 1.2 3s2.1 3.2 5.1 4.5l1.7.6a4 4 0 0 0 1.9.2c.5-.1 1.7-.8 2-1.5q.3-1 .1-1.4z" fill="#04121f" data-original="#000000" fill-rule="evenodd" clip-rule="evenodd"/></svg> '. esc_html( $tab['tab_link_text'] ) .'</div>';
                    } else {
                    if ( $tab['tab_link_text'] ) {
                    ?>
                    <a href="<?= esc_url( $tab['tab_url']['url'] ); ?>" class="c-btn"<?php if ( $tab['tab_url']['is_external'] ) { ?> target="_blank"<?php } ?><?php if ( $tab['tab_url']['nofollow'] ) { ?> rel="nofollow"<?php } ?>>
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 18 18"><path d="M18 2.3H3.2V2A2 2 0 0 0 .9 0H0v1.5h1a1 1 0 0 1 .7.7l1.2 10a2 2 0 0 0 2.2 2H15v-1.4H5a1 1 0 0 1-.7-.7v-.8h12zM5.3 18a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3m7.5 0a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3" fill="#04121F"/></svg>
                        <?= esc_html( $tab['tab_link_text'] ); ?>
                    </a>
                    <?php } } ?>

                </div>

            <?php endforeach; ?>

        </div>

    </div>

    <?php
    if ( $settings['cta_link_text'] ) {
        echo '<div class="c-btn-price-sticky"><svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 18 18"><path d="M18 2.3H3.2V2A2 2 0 0 0 .9 0H0v1.5h1a1 1 0 0 1 .7.7l1.2 10a2 2 0 0 0 2.2 2H15v-1.4H5a1 1 0 0 1-.7-.7v-.8h12zM5.3 18a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3m7.5 0a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3" fill="#04121F"/></svg> '. $settings['cta_link_text'] .'</div>';
    }
    ?>

    </div>

    <div class="epw-close-overlay"></div>
    <div class="epw-overlay-backdrop"></div>

    <?php
    }

    protected function _content_template() { ?>

        <div class="eipro-price-widget-wrap">
            <div class="eipro-price-widget">

                <div class="eipro-price-wrap">
                    <div class="c-dropdown">
                        <button id="licenseButton" class="dropbtn">
                            <#
                            _.each( settings.tabs, function( tab, index ) {
                            var tab_title = tab.tab_title;
                            #>
                                <# if ( index === 0 ) { #>
                                {{{ tab_title }}}
                                <# } #>
                            <# } ); #>
                        </button>
                        <div class="dropdown-content">

                            <#
                            var i = 0;
                            _.each( settings.tabs, function( tab, index ) {
                            i++;
                            var tab_title = tab.tab_title;
                            #>
                                <div class="license-option <# if ( index === 0 ) { #> license-selected <# } #>" data-license="{{{ i }}}" data-label="{{{ tab_title }}}">
                                    {{{ tab_title }}}
                                </div>
                            <# } ); #>

                        </div>
                    </div>
                </div>

                <div class="eipro-price-content">

                    <#
                    var i = 0;
                    _.each( settings.tabs, function( tab, index ) {
                    i++;
                    var displaynone = index === 0 ? '' : 'display: none';
                    #>
                        <div id="license{{{ i }}}" class="license-description" style="{{ displaynone }}">
                            <# if ( tab.tab_subtitle ) { #>
                                <p>{{{ tab.tab_subtitle }}}</p>
                            <# } #>

                            <# if ( tab.tab_list_item ) { #>
                                <ul class="eipro-list-item">
                                    <# _.each( tab.tab_list_item, function( tab_list_item, tab_list_itemIndex ) { #>
                                    <li>{{{ tab_list_item.list_item_text }}}</li>
                                    <# } ); #>
                                </ul>
                            <# } #>

                            <# if ( tab.tab_regular_price ) { #>
                                <div class="c-price">
                                    <span class="<# if ( tab.tab_sale_price ) { #> c-regular-price <# } #>">{{{ tab.tab_regular_price }}}</span>
                                    <# if ( tab.tab_sale_price ) { #>
                                        <span>{{{ tab.tab_sale_price }}}</span>
                                    <# } #>
                                </div>
                            <# } #>

                            <# if ( tab.type_link === 'whatsapp' ) { #>

                            <div class="c-btn c-direct-wa"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" xml:space="preserve"><path d="M20.5 3.5A12 12 0 0 0 12 0 12 12 0 0 0 0 11.9a12 12 0 0 0 1.6 6L.1 24l6.3-1.7a12 12 0 0 0 5.6 1.5 12 12 0 0 0 12-11.9 12 12 0 0 0-3.5-8.4M12 21.8a10 10 0 0 1-5-1.4l-.4-.2-3.8 1 1-3.7-.2-.3a10 10 0 0 1-1.5-5.3 9.9 9.9 0 0 1 16.8-7 10 10 0 0 1 3 7 10 10 0 0 1-10 9.9m5.4-7.4-2-1q-.4-.1-.7.2l-1 1.1q-.2.3-.6.1-.6 0-2.4-1.5-1.4-1.4-1.7-2c-.3-.6 0-.5.2-.6l.4-.6.3-.5v-.5L9 7q-.3-.7-.6-.5h-.6q-.3-.1-.8.4c-.5.5-1 1-1 2.5 0 1.4 1 2.8 1.2 3s2.1 3.2 5.1 4.5l1.7.6a4 4 0 0 0 1.9.2c.5-.1 1.7-.8 2-1.5q.3-1 .1-1.4z" fill="#04121f" data-original="#000000" fill-rule="evenodd" clip-rule="evenodd"/></svg> {{{ tab.tab_link_text }}}</div>

                            <# } else { #>

                            <# if ( tab.tab_link_text ) { #>
                            <a href="{{{ tab.tab_url }}}" class="c-btn">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 18 18"><path d="M18 2.3H3.2V2A2 2 0 0 0 .9 0H0v1.5h1a1 1 0 0 1 .7.7l1.2 10a2 2 0 0 0 2.2 2H15v-1.4H5a1 1 0 0 1-.7-.7v-.8h12zM5.3 18a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3m7.5 0a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3" fill="#04121F"/></svg>
                                {{{ tab.tab_link_text }}}
                            </a>
                            <# } #>
                            <# } #>

                        </div>
                    <# } ); #>

                </div>

        </div>
    </div>

    <?php
    }


}
