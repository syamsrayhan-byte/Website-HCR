<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

class Elementor_Product_Description_Widget extends \Elementor\Widget_Base {

    public function get_name() {
        return 'eipro-product-description-tab';
    }

    public function get_title() {
        return __( 'Product Description - eiPro', 'eipro-addon' );
    }

    public function get_icon() {
        return 'eicon-product-description';
    }

    public function get_categories() {
        return [ 'general' ];
    }

    public function get_keywords() {
        return [ 'product', 'description' ];
    }


    protected function _register_controls() {

        $this->start_controls_section(
            'section_tabs',
            [
                'label' => esc_html__( 'Description', 'eipro-addon' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        /* Start repeater */

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'tab_icon',
            [
                'label' => esc_html__( 'Icon', 'eipro-addon' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
                'dynamic' => [
                    'active' => true,
                ],
            ]
        );

        $repeater->add_control(
            'tab_title',
            [
                'label' => esc_html__( 'Tab Title', 'eipro-addon' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'placeholder' => esc_html__( 'Tab Title', 'eipro-addon' ),
                'default' => esc_html__( 'Tab Title', 'eipro-addon' ),
                'label_block' => true,
                'dynamic' => [
                    'active' => true,
                ],
            ]
        );

        $repeater->add_control(
            'type_content',
            [
                'label' => esc_html__( 'Content', 'eipro-addon' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'desc',
                'options' => [
                    'desc'  => esc_html__( 'Description', 'eipro-addon' ),
                    'testimonial' => esc_html__( 'Testimonial', 'eipro-addon' ),
                    'changelog' => esc_html__( 'Changelog', 'eipro-addon' ),
                    'faq' => esc_html__( 'FAQ', 'eipro-addon' ),
                ],
            ]
        );

        $repeater->add_control(
            'desc_content',
            [
                'label' => esc_html__( 'Description', 'eipro-addon' ),
                'type' => \Elementor\Controls_Manager::WYSIWYG,
                'placeholder' => esc_html__( 'Description', 'eipro-addon' ),
                'default' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.',
                'label_block' => true,
                'condition' => [
                    'type_content' => 'desc',
                ],
                'dynamic' => [
                    'active' => true,
                ],
            ]
        );

        $repeater->add_control(
            'testimonial_content',
            [
                'label' => esc_html__( 'Testimonials', 'eipro-addon' ),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => [
                    [
                        'name' => 'testimonial_image',
                        'label' => esc_html__( 'Choose Image', 'eipro-addon' ),
                        'type' => \Elementor\Controls_Manager::MEDIA,
                        'default' => [
                            'url' => \Elementor\Utils::get_placeholder_image_src(),
                        ],
                        'label_block' => true,
                        'dynamic' => [
                            'active' => true,
                        ],
                    ],
                    [
                        'name' => 'testimonial_name',
                        'label' => esc_html__( 'Name', 'eipro-addon' ),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'placeholder' => esc_html__( 'John Doe', 'eipro-addon' ),
                        'default' => esc_html__( 'John Doe', 'eipro-addon' ),
                        'label_block' => true,
                        'dynamic' => [
                            'active' => true,
                        ],
                    ],
                    [
                        'name' => 'testimonial_title',
                        'label' => esc_html__( 'Title', 'eipro-addon' ),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'placeholder' => esc_html__( 'Designer', 'eipro-addon' ),
                        'default' => esc_html__( 'Designer', 'eipro-addon' ),
                        'label_block' => true,
                        'dynamic' => [
                            'active' => true,
                        ],
                    ],
                    [
                        'name' => 'testimonial_desc',
                        'label' => esc_html__( 'Description', 'eipro-addon' ),
                        'type' => \Elementor\Controls_Manager::WYSIWYG,
                        'placeholder' => esc_html__( 'Description', 'eipro-addon' ),
                        'label_block' => true,
                        'dynamic' => [
                            'active' => true,
                        ],
                    ],
                ],
                'default' => [
                    [
                        'testimonial_name' => 'John Doe',
                    ],
                ],
                'condition' => [
                    'type_content' => 'testimonial',
                ],
                'title_field' => '{{{ testimonial_name }}}',
            ]
        );

        $repeater->add_control(
            'changelog_content',
            [
                'label' => esc_html__( 'Changelog', 'eipro-addon' ),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => [
                    [
                        'name' => 'changelog_version',
                        'label' => esc_html__( 'Version', 'eipro-addon' ),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'placeholder' => esc_html__( 'v1.0.0', 'eipro-addon' ),
                        'default' => esc_html__( 'v1.0.0', 'eipro-addon' ),
                        'label_block' => true,
                        'dynamic' => [
                            'active' => true,
                        ],
                    ],
                    [
                        'name' => 'changelog_date',
                        'label' => esc_html__( 'Date', 'eipro-addon' ),
                        'type' => \Elementor\Controls_Manager::DATE_TIME,
                        'picker_options' => [
                            'enableTime' => false,
                            'dateFormat' => 'Y-m-d',
                        ],
                    ],
                    [
                        'name' => 'changelog_desc',
                        'label' => esc_html__( 'Description', 'eipro-addon' ),
                        'type' => \Elementor\Controls_Manager::WYSIWYG,
                        'placeholder' => esc_html__( 'Description', 'eipro-addon' ),
                        'label_block' => true,
                        'dynamic' => [
                            'active' => true,
                        ],
                    ],
                ],
                'default' => [
                    [
                        'changelog_version' => 'v1.0.0',
                    ],
                ],
                'condition' => [
                    'type_content' => 'changelog',
                ],
                'title_field' => '{{{ changelog_version }}}',
            ]
        );

        $repeater->add_control(
            'faq_content',
            [
                'label' => esc_html__( 'FAQ', 'eipro-addon' ),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => [
                    [
                        'name' => 'faq_title',
                        'label' => esc_html__( 'Title', 'eipro-addon' ),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'placeholder' => esc_html__( 'Title', 'eipro-addon' ),
                        'default' => esc_html__( 'Title', 'eipro-addon' ),
                        'label_block' => true,
                        'dynamic' => [
                            'active' => true,
                        ],
                    ],
                    [
                        'name' => 'faq_desc',
                        'label' => esc_html__( 'Description', 'eipro-addon' ),
                        'type' => \Elementor\Controls_Manager::WYSIWYG,
                        'placeholder' => esc_html__( 'Description', 'eipro-addon' ),
                        'label_block' => true,
                        'dynamic' => [
                            'active' => true,
                        ],
                    ],
                ],
                'default' => [
                    [
                        'faq_title' => 'Title',
                    ],
                ],
                'condition' => [
                    'type_content' => 'faq',
                ],
                'title_field' => '{{{ faq_title }}}',
            ]
        );

        $this->add_control(
            'tabs',
            [
                'label' => esc_html__( 'Tabs', 'eipro-addon' ),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),           /* Use our repeater */
                'default' => [
                    [
                        'tab_icon' => \Elementor\Utils::get_placeholder_image_src(),
                        'tab_title' => esc_html__( 'Tab Title #1', 'eipro-addon' ),
                    ],
                    [
                        'tab_icon' => \Elementor\Utils::get_placeholder_image_src(),
                        'tab_title' => esc_html__( 'Tab Title #2', 'eipro-addon' ),
                    ],
                    [
                        'tab_icon' => \Elementor\Utils::get_placeholder_image_src(),
                        'tab_title' => esc_html__( 'Tab Title #3', 'eipro-addon' ),
                    ],
                ],
                'title_field' => '{{{ tab_title }}}',
            ]
        );


        $this->end_controls_section();

    }

    protected function render() {

        $settings = $this->get_settings_for_display(); ?>

        <div class="eipro-product-desc-widget">
            <div class="eipro-d-tab-wrap">
                <div class="">
                    <ul class="eipro-d-nav">

                        <?php $i = 0; foreach ( $settings['tabs'] as $index => $tab ) : $i++; ?>
                        <li class="eipro-d-nav-item<?php if ( $index === 0 ) : ?> eipro-d-active<?php endif; ?><?php if(!$tab['tab_icon']['url']){echo ' no-icon';} ?>">
                            <a href="#eipro-d-tab<?= $i; ?>" class="eipro-d-nav-link">
                                <?php
                                if ( $tab['tab_icon']['url'] ) {
                                    echo '<img src="' . esc_url( $tab['tab_icon']['url'] ) . '" alt="Icon - ' . esc_attr( $tab['tab_title'] ) . '">';
                                }
                                ?>
                                <span><?php echo esc_html( $tab['tab_title'] ); ?></span>
                            </a>
                        </li>
                        <?php endforeach; ?>

                        <div class="eipro-d-nav-scroll-icon-left">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="512" height="512"><g id="_01_align_center" data-name="01 align center"><path d="M16.752,23.994,6.879,14.121a3,3,0,0,1,0-4.242L16.746.012,18.16,1.426,8.293,11.293a1,1,0,0,0,0,1.414l9.873,9.873Z"/></g></svg>
                        </div>
                        <div class="eipro-d-nav-scroll-icon-right">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="512" height="512"><g id="_01_align_center" data-name="01 align center"><path d="M7.412,24,6,22.588l9.881-9.881a1,1,0,0,0,0-1.414L6.017,1.431,7.431.017l9.862,9.862a3,3,0,0,1,0,4.242Z"/></g></svg>
                        </div>
                        <div class="eipro-d-nav-graduated-filter-left"></div>
                        <div class="eipro-d-nav-graduated-filter-right"></div>

                    </ul>
                </div>
            </div>
            <div class="eipro-d-tab-content">

                <?php $i = 0; foreach ( $settings['tabs'] as $index => $tab ) : $i++; ?>
                <div class="eipro-d-tab-tab<?php if ( $index === 0 ) : ?> eipro-d-active<?php endif; ?>" id="eipro-d-tab<?= $i; ?>">

                    <?php if ( $tab['type_content'] === 'desc' ) { ?>
                    <div class="eipro-d-desc-wrap">
                        <?= $tab['desc_content']; ?>
                    </div>

                    <?php } else if ( $tab['type_content'] === 'testimonial' ) { ?>
                    <div class="eipro-d-testimonial-wrap">

                        <?php
                        $colors = array('#CB5D79', '#EA8F63', '#C7C561', '#4C7DC7', '#8D5692', '#657B9A');
                        $i = 0;
                        foreach ( $tab['testimonial_content'] as $testimonial_content ) {
                            $color = $colors[$i % count($colors)];
                            $i++;
                        ?>
                        <div class="eipro-d-testimonial-list">
                            <div class="eipro-d-testimonial-img">
                                <img src="<?= $testimonial_content['testimonial_image']['url']; ?>" alt="<?= esc_attr( $testimonial_content['testimonial_name'] ); ?>" style="border-color: <?= $color; ?> !important;">
                            </div>
                            <div class="eipro-d-testimonial-content">
                                <div class="eipro-d-testimonial-name">
                                    <?= esc_html ( $testimonial_content['testimonial_name'] ); ?>
                                    <?php
                                    if ( $testimonial_content['testimonial_title'] ) {
                                        echo '<span>'. esc_html ( $testimonial_content['testimonial_title'] ) .'</span>';
                                    }
                                    ?>
                                </div>
                                <div class="eipro-d-testimonial-desc">
                                    <div class="eipro-d-testimonial-rating">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="17" viewBox="0 0 18 17" fill="none"><path d="M6.31753 5.00252L8.52542 0.555149C8.80881 -0.0157788 9.6277 -0.0157788 9.91109 0.555149L12.119 5.00252L17.0565 5.72009C17.69 5.81216 17.9425 6.58644 17.4839 7.03056L13.9117 10.49L14.7547 15.3771C14.863 16.0048 14.2004 16.4833 13.6336 16.1869L9.21826 13.8782L4.80291 16.1869C4.23607 16.4833 3.57349 16.0048 3.68174 15.3771L4.52477 10.49L0.952651 7.03056C0.494008 6.58644 0.7465 5.81216 1.38 5.72009L6.31753 5.00252Z" fill="#FFB422"/></svg><svg xmlns="http://www.w3.org/2000/svg" width="18" height="17" viewBox="0 0 18 17" fill="none"><path d="M6.31753 5.00252L8.52542 0.555149C8.80881 -0.0157788 9.6277 -0.0157788 9.91109 0.555149L12.119 5.00252L17.0565 5.72009C17.69 5.81216 17.9425 6.58644 17.4839 7.03056L13.9117 10.49L14.7547 15.3771C14.863 16.0048 14.2004 16.4833 13.6336 16.1869L9.21826 13.8782L4.80291 16.1869C4.23607 16.4833 3.57349 16.0048 3.68174 15.3771L4.52477 10.49L0.952651 7.03056C0.494008 6.58644 0.7465 5.81216 1.38 5.72009L6.31753 5.00252Z" fill="#FFB422"/></svg><svg xmlns="http://www.w3.org/2000/svg" width="18" height="17" viewBox="0 0 18 17" fill="none"><path d="M6.31753 5.00252L8.52542 0.555149C8.80881 -0.0157788 9.6277 -0.0157788 9.91109 0.555149L12.119 5.00252L17.0565 5.72009C17.69 5.81216 17.9425 6.58644 17.4839 7.03056L13.9117 10.49L14.7547 15.3771C14.863 16.0048 14.2004 16.4833 13.6336 16.1869L9.21826 13.8782L4.80291 16.1869C4.23607 16.4833 3.57349 16.0048 3.68174 15.3771L4.52477 10.49L0.952651 7.03056C0.494008 6.58644 0.7465 5.81216 1.38 5.72009L6.31753 5.00252Z" fill="#FFB422"/></svg><svg xmlns="http://www.w3.org/2000/svg" width="18" height="17" viewBox="0 0 18 17" fill="none"><path d="M6.31753 5.00252L8.52542 0.555149C8.80881 -0.0157788 9.6277 -0.0157788 9.91109 0.555149L12.119 5.00252L17.0565 5.72009C17.69 5.81216 17.9425 6.58644 17.4839 7.03056L13.9117 10.49L14.7547 15.3771C14.863 16.0048 14.2004 16.4833 13.6336 16.1869L9.21826 13.8782L4.80291 16.1869C4.23607 16.4833 3.57349 16.0048 3.68174 15.3771L4.52477 10.49L0.952651 7.03056C0.494008 6.58644 0.7465 5.81216 1.38 5.72009L6.31753 5.00252Z" fill="#FFB422"/></svg><svg xmlns="http://www.w3.org/2000/svg" width="18" height="17" viewBox="0 0 18 17" fill="none"><path d="M6.31753 5.00252L8.52542 0.555149C8.80881 -0.0157788 9.6277 -0.0157788 9.91109 0.555149L12.119 5.00252L17.0565 5.72009C17.69 5.81216 17.9425 6.58644 17.4839 7.03056L13.9117 10.49L14.7547 15.3771C14.863 16.0048 14.2004 16.4833 13.6336 16.1869L9.21826 13.8782L4.80291 16.1869C4.23607 16.4833 3.57349 16.0048 3.68174 15.3771L4.52477 10.49L0.952651 7.03056C0.494008 6.58644 0.7465 5.81216 1.38 5.72009L6.31753 5.00252Z" fill="#FFB422"/></svg>
                                    </div>
                                    <?= $testimonial_content['testimonial_desc']; ?>
                                </div>
                            </div>
                        </div>
                        <?php } ?>

                    </div>

                    <?php } else if ( $tab['type_content'] === 'changelog' ) { ?>
                    <div class="eipro-d-changelog-wrap">

                        <?php foreach ( $tab['changelog_content'] as $changelog_content ) { ?>
                        <div class="eipro-d-changelog-list">
                            <div class="eipro-d-changelog-v">
                                <?= $changelog_content['changelog_version']; ?>
                                <?php
                                if ( $changelog_content['changelog_date'] ) {
                                    $date_time_obj = new DateTime($changelog_content['changelog_date']);
                                    $formatted_date = $date_time_obj->format('M d, Y');
                                    echo '<span>'. $formatted_date .'</span>';
                                }
                                ?>
                            </div>
                            <div class="eipro-d-changelog-box">
                                <?= $changelog_content['changelog_desc']; ?>
                            </div>
                        </div>
                        <?php } ?>

                    </div>

                    <?php } else if ( $tab['type_content'] === 'faq' ) { ?>
                    <div class="eipro-d-faq-wrap">
                        
                        <?php foreach ( $tab['faq_content'] as $index => $faq_content ) { ?>
                        <div class="eipro-d-faq-list">
                            <div class="eipro-d-faq-title<?php if ( $index === 0 ) : ?> eipro-d-faq-active<?php endif; ?>">
                                <?= esc_html ( $faq_content['faq_title'] ); ?>
                                <span class="eipro-d-faq-icon">Icon</span>
                            </div>
                            <div class="eipro-d-faq-desc<?php if ( $index === 0 ) : ?> desc-active<?php endif; ?>" style="<?php if ( $index === 0 ) {}else{echo 'height: 0px';} ?>">
                                <?= $faq_content['faq_desc']; ?>
                            </div>
                        </div>
                        <?php } ?>

                    </div>
                    <?php } ?>

                </div>
                <?php endforeach; ?>

            </div>
        </div>

    <?php
    }

    protected function _content_template() { ?>

    <div class="eipro-product-desc-widget">
        <div class="eipro-d-tab-wrap">
            <div class="">
                <ul class="eipro-d-nav">

                    <#
                    _.each( settings.tabs, function( tab, index ) {
                    var tab_icon = tab.tab_icon.url;
                    var tab_title = tab.tab_title;
                    #>
                    <li class="eipro-d-nav-item<# if ( index === 0 ) { #> eipro-d-active<# } #><# if ( !tab_icon ) { #> no-icon<# } #>">
                        <a href="#" class="eipro-d-nav-link">
                            <# if ( tab_icon ) { #>
                                <img src="{{{ tab_icon }}}" alt="Icon - {{{ tab_title.alt }}}" />
                            <# } #>
                            <span>{{{ tab_title }}}</span>
                        </a>
                    </li>
                    <# } ); #>

                    <div class="eipro-d-nav-graduated-filter-right"></div>

                </ul>
            </div>
        </div>
        <div class="eipro-d-tab-content">

            <#
            _.each( settings.tabs, function( tab, index ) {
            #>
            <div class="eipro-d-tab-tab<# if ( index === 0 ) { #> eipro-d-active<# } #>">

                <# if ( tab.type_content === 'desc' ) { #>
                <div class="eipro-d-desc-wrap">
                    {{{ tab.desc_content }}}
                </div>
                <# } #>

                <# if ( tab.type_content === 'testimonial' ) { #>
                <div class="eipro-d-testimonial-wrap">
                    <#
                    var colors = ['#CB5D79', '#EA8F63', '#C7C561', '#4C7DC7', '#8D5692', '#657B9A'];
                    var i = 0;
                    _.each( tab.testimonial_content, function( testi, testiIndex ) {
                        var color = colors[i % colors.length];
                        i++;
                    #>
                    <div class="eipro-d-testimonial-list">
                        <div class="eipro-d-testimonial-img">
                            <img src="{{{ testi.testimonial_image.url }}}" alt="{{{ testi.testimonial_name.alt }}}" style="border-color: {{{ color }}} !important;">
                        </div>
                        <div class="eipro-d-testimonial-content">
                            <div class="eipro-d-testimonial-name">
                                {{{ testi.testimonial_name }}}
                                <# if ( testi.testimonial_title ) { #>
                                    <span>{{{ testi.testimonial_title }}}</span>
                                <# } #>
                            </div>
                            <div class="eipro-d-testimonial-desc">
                                <div class="eipro-d-testimonial-rating">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="17" viewBox="0 0 18 17" fill="none"><path d="M6.31753 5.00252L8.52542 0.555149C8.80881 -0.0157788 9.6277 -0.0157788 9.91109 0.555149L12.119 5.00252L17.0565 5.72009C17.69 5.81216 17.9425 6.58644 17.4839 7.03056L13.9117 10.49L14.7547 15.3771C14.863 16.0048 14.2004 16.4833 13.6336 16.1869L9.21826 13.8782L4.80291 16.1869C4.23607 16.4833 3.57349 16.0048 3.68174 15.3771L4.52477 10.49L0.952651 7.03056C0.494008 6.58644 0.7465 5.81216 1.38 5.72009L6.31753 5.00252Z" fill="#FFB422"/></svg><svg xmlns="http://www.w3.org/2000/svg" width="18" height="17" viewBox="0 0 18 17" fill="none"><path d="M6.31753 5.00252L8.52542 0.555149C8.80881 -0.0157788 9.6277 -0.0157788 9.91109 0.555149L12.119 5.00252L17.0565 5.72009C17.69 5.81216 17.9425 6.58644 17.4839 7.03056L13.9117 10.49L14.7547 15.3771C14.863 16.0048 14.2004 16.4833 13.6336 16.1869L9.21826 13.8782L4.80291 16.1869C4.23607 16.4833 3.57349 16.0048 3.68174 15.3771L4.52477 10.49L0.952651 7.03056C0.494008 6.58644 0.7465 5.81216 1.38 5.72009L6.31753 5.00252Z" fill="#FFB422"/></svg><svg xmlns="http://www.w3.org/2000/svg" width="18" height="17" viewBox="0 0 18 17" fill="none"><path d="M6.31753 5.00252L8.52542 0.555149C8.80881 -0.0157788 9.6277 -0.0157788 9.91109 0.555149L12.119 5.00252L17.0565 5.72009C17.69 5.81216 17.9425 6.58644 17.4839 7.03056L13.9117 10.49L14.7547 15.3771C14.863 16.0048 14.2004 16.4833 13.6336 16.1869L9.21826 13.8782L4.80291 16.1869C4.23607 16.4833 3.57349 16.0048 3.68174 15.3771L4.52477 10.49L0.952651 7.03056C0.494008 6.58644 0.7465 5.81216 1.38 5.72009L6.31753 5.00252Z" fill="#FFB422"/></svg><svg xmlns="http://www.w3.org/2000/svg" width="18" height="17" viewBox="0 0 18 17" fill="none"><path d="M6.31753 5.00252L8.52542 0.555149C8.80881 -0.0157788 9.6277 -0.0157788 9.91109 0.555149L12.119 5.00252L17.0565 5.72009C17.69 5.81216 17.9425 6.58644 17.4839 7.03056L13.9117 10.49L14.7547 15.3771C14.863 16.0048 14.2004 16.4833 13.6336 16.1869L9.21826 13.8782L4.80291 16.1869C4.23607 16.4833 3.57349 16.0048 3.68174 15.3771L4.52477 10.49L0.952651 7.03056C0.494008 6.58644 0.7465 5.81216 1.38 5.72009L6.31753 5.00252Z" fill="#FFB422"/></svg><svg xmlns="http://www.w3.org/2000/svg" width="18" height="17" viewBox="0 0 18 17" fill="none"><path d="M6.31753 5.00252L8.52542 0.555149C8.80881 -0.0157788 9.6277 -0.0157788 9.91109 0.555149L12.119 5.00252L17.0565 5.72009C17.69 5.81216 17.9425 6.58644 17.4839 7.03056L13.9117 10.49L14.7547 15.3771C14.863 16.0048 14.2004 16.4833 13.6336 16.1869L9.21826 13.8782L4.80291 16.1869C4.23607 16.4833 3.57349 16.0048 3.68174 15.3771L4.52477 10.49L0.952651 7.03056C0.494008 6.58644 0.7465 5.81216 1.38 5.72009L6.31753 5.00252Z" fill="#FFB422"/></svg>
                                </div>
                                {{{ testi.testimonial_desc }}}
                            </div>
                        </div>
                    </div>
                    <# } ); #>
                </div>
                <# } #>

                <# if ( tab.type_content === 'changelog' ) { #>
                <div class="eipro-d-changelog-wrap">

                    <#
                    _.each( tab.changelog_content, function( changelog, changelogIndex ) {
                    #>
                    <div class="eipro-d-changelog-list">
                        <div class="eipro-d-changelog-v">
                            {{{ changelog.changelog_version }}}
                        </div>
                        <div class="eipro-d-changelog-box">
                            {{{ changelog.changelog_desc }}}
                        </div>
                    </div>
                    <# } ); #>

                </div>
                <# } #>

                <# if ( tab.type_content === 'faq' ) { #>
                <div class="eipro-d-faq-wrap">

                    <#
                    _.each( tab.faq_content, function( faq, faqIndex ) {
                    #>
                    <div class="eipro-d-faq-list">
                        <div class="eipro-d-faq-title<# if ( faqIndex === 0 ) { #> eipro-d-faq-active<# } #>">
                            {{{ faq.faq_title }}}
                            <span class="eipro-d-faq-icon">Icon</span>
                        </div>
                        <div class="eipro-d-faq-desc<# if ( faqIndex === 0 ) { #> desc-active<# } #>" style="<# if ( faqIndex === 0 ) { } else { #> height: 0px <# } #>">
                            {{{ faq.faq_desc }}}
                        </div>
                    </div>
                    <# } ); #>

                </div>
                <# } #>

            </div>
            <# } ); #>

        </div>
    </div>

    <?php
    }


}