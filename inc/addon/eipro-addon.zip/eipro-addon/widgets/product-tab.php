<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

class Elementor_Product_Tab_Widget extends \Elementor\Widget_Base {

    public function get_name() {
        return 'eipro-product-tab';
    }

    public function get_title() {
        return __( 'Product Tabs - eiPro', 'eipro-addon' );
    }

    public function get_icon() {
        return 'eicon-tabs';
    }

    public function get_categories() {
        return [ 'general' ];
    }

    public function get_keywords() {
        return [ 'tab', 'tabs', 'product', 'list' ];
    }


    protected function _register_controls() {

        $this->start_controls_section(
            'section_tabs',
            [
                'label' => esc_html__( 'Tab Content', 'eipro-addon' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'show_first_tab',
            [
                'label' => esc_html__( 'Show First Tab', 'eipro-addon' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'default' => 'no',
            ]
        );

        $this->add_control(
            'show_first_tab_thumb',
            [
                'label' => esc_html__( 'Thumbnail', 'eipro-addon' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'show_first_tab' => 'yes',
                ],
                'dynamic' => [
                    'active' => true,
                ],
            ]
        );

        $this->add_control(
            'show_first_tab_text',
            [
                'label' => esc_html__( 'Tab Title', 'eipro-addon' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'placeholder' => esc_html__( 'All Products', 'eipro-addon' ),
                'default' => esc_html__( 'All Products', 'eipro-addon' ),
                'condition' => [
                    'show_first_tab' => 'yes',
                ],
                'dynamic' => [
                    'active' => true,
                ],
            ]
        );

        $this->add_control(
            'show_first_tab_description',
            [
                'label' => esc_html__( 'Description', 'eipro-addon' ),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'placeholder' => esc_html__( 'Description', 'eipro-addon' ),
                'condition' => [
                    'show_first_tab' => 'yes',
                ],
                'dynamic' => [
                    'active' => true,
                ],
            ]
        );

        /* Start repeater */

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'tab_thumb',
            [
                'label' => esc_html__( 'Thumbnail', 'eipro-addon' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
                'dynamic' => [
                    'active' => true,
                ],
            ]
        );

        $repeater->add_control(
            'tab_title',
            [
                'label' => esc_html__( 'Tab Title', 'eipro-addon' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'placeholder' => esc_html__( 'Tab Title', 'eipro-addon' ),
                'default' => esc_html__( 'Tab Title', 'eipro-addon' ),
                'label_block' => true,
                'dynamic' => [
                    'active' => true,
                ],
            ]
        );

        $repeater->add_control(
            'tab_subtitle',
            [
                'label' => esc_html__( 'Description', 'eipro-addon' ),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'placeholder' => esc_html__( 'Description', 'eipro-addon' ),
                'default' => esc_html__( 'Lorem ipsum dolor amet labore magna aliqua.', 'eipro-addon' ),
                'label_block' => true,
                'dynamic' => [
                    'active' => true,
                ],
            ]
        );

        $repeater->add_control(
            'product',
            [
                'label' => esc_html__( 'Products', 'eipro-addon' ),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => [
                    [
                        'name' => 'product_image',
                        'label' => esc_html__( 'Image', 'eipro-addon' ),
                        'type' => \Elementor\Controls_Manager::MEDIA,
                        'default' => [
                            'url' => \Elementor\Utils::get_placeholder_image_src(),
                        ],
                        'dynamic' => [
                            'active' => true,
                        ],
                    ],
                    [
                        'name' => 'product_title',
                        'label' => esc_html__( 'Title', 'eipro-addon' ),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'placeholder' => esc_html__( 'Product Title', 'eipro-addon' ),
                        'default' => 'Product Title',
                        'label_block' => true,
                        'dynamic' => [
                            'active' => true,
                        ],
                    ],
                    [
                        'name' => 'product_text',
                        'label' => esc_html__( 'Text', 'eipro-addon' ),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'placeholder' => esc_html__( 'Get Special Price', 'eipro-addon' ),
                        'default' => 'Get Special Price',
                        'label_block' => true,
                        'dynamic' => [
                            'active' => true,
                        ],
                    ],
                    [
                        'name' => 'product_regular_price',
                        'label' => esc_html__( 'Regular Price', 'eipro-addon' ),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'placeholder' => esc_html__( 'Rp 999', 'eipro-addon' ),
                        'default' => 'Rp 999',
                        'label_block' => true,
                        'dynamic' => [
                            'active' => true,
                        ],
                    ],
                    [
                        'name' => 'product_sale_price',
                        'label' => esc_html__( 'Sale Price', 'eipro-addon' ),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'placeholder' => esc_html__( 'Rp 888', 'eipro-addon' ),
                        'default' => 'Rp 888',
                        'label_block' => true,
                        'dynamic' => [
                            'active' => true,
                        ],
                    ],
                    [
                        'name' => 'product_link',
                        'label' => esc_html__( 'Link', 'eipro-addon' ),
                        'type' => \Elementor\Controls_Manager::URL,
                        'placeholder' => __( 'https://example.com', 'eipro-addon' ),
                        'default' => [
                            'url' => '',
                            'is_external' => false,
                            'nofollow' => false,
                        ],
                        'dynamic' => [
                            'active' => true,
                        ],
                    ],
                    [
                        'name' => 'enable_product_link_icon',
                        'label' => esc_html__( 'Enable Icon', 'eipro-addon' ),
                        'type' => \Elementor\Controls_Manager::SWITCHER,
                        'default' => 'no',
                    ],
                    [
                        'name' => 'product_link_icon',
                        'label' => esc_html__( '', 'eipro-addon' ),
                        'type' => \Elementor\Controls_Manager::ICONS,
                        'condition' => [
                            'enable_product_link_icon' => 'yes',
                        ],
                        'label_block' => true,
                    ],
                ],
                'default' => [
                    [
                        'product_title' => 'Product Title',
                        'product_link' => [
                            'url' => '',
                            'is_external' => false,
                            'nofollow' => false,
                        ],
                    ],
                ],
                'title_field' => '{{{ product_title }}}',
            ]
        );

        $this->add_control(
            'tabs',
            [
                'label' => esc_html__( 'Tabs', 'eipro-addon' ),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),           /* Use our repeater */
                'default' => [
                    [
                        'tab_thumb' => \Elementor\Utils::get_placeholder_image_src(),
                        'tab_title' => esc_html__( 'Tab Title #1', 'eipro-addon' ),
                        'tab_subtitle' => esc_html__( 'Lorem ipsum dolor amet labore magna aliqua.', 'eipro-addon' ),
                    ],
                    [
                        'tab_thumb' => \Elementor\Utils::get_placeholder_image_src(),
                        'tab_title' => esc_html__( 'Tab Title #2', 'eipro-addon' ),
                        'tab_subtitle' => esc_html__( 'Lorem ipsum dolor amet labore magna aliqua.', 'eipro-addon' ),
                    ],
                    [
                        'tab_thumb' => \Elementor\Utils::get_placeholder_image_src(),
                        'tab_title' => esc_html__( 'Tab Title #3', 'eipro-addon' ),
                        'tab_subtitle' => esc_html__( 'Lorem ipsum dolor amet labore magna aliqua.', 'eipro-addon' ),
                    ],
                ],
                'title_field' => '{{{ tab_title }}}',
            ]
        );


        $this->end_controls_section();

        $this->start_controls_section(
            'section_tab_options',
            [
                'label' => esc_html__( 'Additional Options', 'eipro-addon' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'more_products_btn',
            [
                'label' => esc_html__( 'Button (More Products)', 'eipro-addon' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'placeholder' => esc_html__( 'More Products', 'eipro-addon' ),
                'default' => esc_html__( 'More Products', 'eipro-addon' ),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'products_to_show',
            [
                'label' => __( 'Products to Show', 'eipro-addon' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'min' => 1,
                'max' => 42,
                'default' => 6,
            ]
        );

        $this->end_controls_section();

    }

    protected function render() {

        $settings = $this->get_settings_for_display();
        $all_tab = $settings['tabs'];
        $show_first_tab = $settings['show_first_tab'];
        $show_first_tab_text = $settings['show_first_tab_text'] ? $settings['show_first_tab_text'] : esc_html( 'All Products', 'eipro-addon' );
        $show_first_tab_description = $settings['show_first_tab_description'];

        if ( $show_first_tab === 'yes' ) {
        $show_first_tab_thumb = $settings['show_first_tab_thumb']['url'];
        ?>

        <div class="eipro-tabs-widget">

            <div class="eipro-tabs-wrap e-tabs-sticky">
                <div class="eipro-tabs-sticky">
                    <div>
                        <ul class="eipro-tabs-nav">
                            <li class="eipro-tabs-nav-item eipro-tab-active<?php if(!$show_first_tab_thumb){echo ' no-thumb';} ?>">
                                <a href="#c-all-product" class="eipro-tabs-nav-link">
                                    <?php
                                    if ( $show_first_tab_thumb ) {
                                        echo '<img src="' . esc_url( $show_first_tab_thumb ) . '" alt="' . esc_attr( $show_first_tab_text ) . '">';
                                    }
                                    ?>
                                    <span><?php echo $show_first_tab_text; ?></span>
                                    <?php
                                    if ( $show_first_tab_description ) {
                                        echo '<span class="c-desc">' . $show_first_tab_description . '</span>';
                                    }
                                    ?>
                                </a>
                            </li>
                            <?php $i = 0; foreach ( $settings['tabs'] as $index => $tab ) : $i++; ?>
                                <li class="eipro-tabs-nav-item<?php if(!$tab['tab_thumb']['url']){echo ' no-thumb';} ?>">
                                    <a href="#eipro-tabs-tab<?= $i; ?>" class="eipro-tabs-nav-link">
                                        <?php
                                        if ( $tab['tab_thumb']['url'] ) {
                                            echo '<img src="' . esc_url( $tab['tab_thumb']['url'] ) . '" alt="' . esc_attr( $tab['tab_title'] ) . '">';
                                        }
                                        ?>
                                        <span><?php echo esc_html( $tab['tab_title'] ); ?></span>
                                        <?php
                                            if ( $tab['tab_subtitle'] ) {
                                                echo '<span class="c-desc">' . esc_html( $tab['tab_subtitle'] ) . '</span>';
                                            }
                                        ?>
                                    </a>
                                </li>
                            <?php endforeach; ?>

                            <div class="eipro-d-nav-scroll-icon-left">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="512" height="512"><g id="_01_align_center" data-name="01 align center"><path d="M16.752,23.994,6.879,14.121a3,3,0,0,1,0-4.242L16.746.012,18.16,1.426,8.293,11.293a1,1,0,0,0,0,1.414l9.873,9.873Z"/></g></svg>
                            </div>
                            <div class="eipro-d-nav-scroll-icon-right">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="512" height="512"><g id="_01_align_center" data-name="01 align center"><path d="M7.412,24,6,22.588l9.881-9.881a1,1,0,0,0,0-1.414L6.017,1.431,7.431.017l9.862,9.862a3,3,0,0,1,0,4.242Z"/></g></svg>
                            </div>
                            <div class="eipro-d-nav-graduated-filter-left"></div>
                            <div class="eipro-d-nav-graduated-filter-right"></div>

                        </ul>
                    </div>
                </div>
            </div>

            <div class="eipro-tabs-content">

                <div class="eipro-tabs-tab eipro-tab-active" id="c-all-product">

                <?php
                $p_number = $settings['products_to_show'];
                $m_product_btn = $settings['more_products_btn'];
                ?>
                <div class="eipro-list" data-load-limit="<?php echo esc_html(!empty($p_number) ? $p_number : 6); ?>">

                <?php foreach ( $all_tab as $tab ) { ?>

                <?php if ( $tab['product'] ) : ?>

                    <?php foreach ( $tab['product'] as $product ) : ?>

                        <div class="eipro-list-item<?php if ( $product['enable_product_link_icon'] === 'yes' ) {echo ' ei-with-icon';} ?>">
                            <div>

                                <?php if ( $product['product_link']['url'] ) : ?>
                                <a href="<?php echo esc_url( $product['product_link']['url'] ); ?>"<?php if ( $product['product_link']['is_external'] ) : ?> target="_blank"<?php endif; ?><?php if ( $product['product_link']['nofollow'] ) : ?> rel="nofollow"<?php endif; ?>>
                                <?php endif; ?>
                                <?php if ( $product['product_image']['url'] ) : ?>
                                    <img src="<?php echo esc_url( $product['product_image']['url'] ); ?>" alt="<?php echo esc_attr( $product['product_title'] ); ?>">
                                <?php endif; ?>
                                <div class="ei-content-bottom<?php if ($product['product_sale_price']) {echo ' eipro-regular-price-active';} ?>">
                                    <div class="eipro-subtitle"><?php echo wp_kses_post( $tab['tab_title'] ); ?></div>
                                    <div class="eipro-title"><?php echo esc_html( $product['product_title'] ); ?></div>
                                    <div class="eipro-product-text-price">
                                    <?php
                                    if ($product['product_text']) {
                                        echo '<div class="eipro-text">' . esc_html( $product['product_text'] ) . '</div>';
                                    }
                                    ?>
                                    <?php if ($product['product_regular_price']) { ?>
                                        <div class="eipro-price">
                                            <?php
                                            if ( $product['product_sale_price'] ) {
                                                echo '<span>'. esc_html( $product['product_sale_price'] ) .'</span>';
                                            }
                                            ?>
                                            <span<?php if ( $product['product_sale_price'] ) { echo ' class="eipro-regular-price"'; } ?>>
                                                <?= esc_html( $product['product_regular_price'] ); ?>
                                            </span>
                                        </div>
                                    <?php } ?>
                                    </div>

                                    <?php if ( $product['enable_product_link_icon'] === 'yes' ) : ?>
                                    <div class="ei-cart-btn">
                                        <span>
                                            <?php \Elementor\Icons_Manager::render_icon( $product['product_link_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                                        </span>
                                    </div>
                                    <?php endif; ?>

                                </div>
                                <?php if ( $product['product_link']['url'] ) : ?>
                                </a>
                                <?php endif; ?>

                            </div>
                        </div>

                    <?php endforeach; ?>

                <?php endif; } ?>

                <div class="ei-more-product">
                    <span><?php echo esc_html(!empty($m_product_btn) ? $m_product_btn : 'More Products'); ?></span>
                </div>

                </div>

            </div>

            <?php $i = 0; foreach ( $settings['tabs'] as $index => $tab ) : $i++; ?>
                <div class="eipro-tabs-tab" id="eipro-tabs-tab<?= $i; ?>">

                <?php if ( $tab['product'] ) : ?>

                    <?php
                    $p_number = $settings['products_to_show'];
                    $m_product_btn = $settings['more_products_btn'];
                    ?>

                    <div class="eipro-list" data-load-limit="<?php echo esc_html(!empty($p_number) ? $p_number : 6); ?>">

                    <?php foreach ( $tab['product'] as $product ) : ?>

                        <div class="eipro-list-item<?php if ( $product['enable_product_link_icon'] === 'yes' ) {echo ' ei-with-icon';} ?>">
                            <div>
                                <?php if ( $product['product_link']['url'] ) : ?>
                                <a href="<?php echo esc_url( $product['product_link']['url'] ); ?>"<?php if ( $product['product_link']['is_external'] ) : ?> target="_blank"<?php endif; ?><?php if ( $product['product_link']['nofollow'] ) : ?> rel="nofollow"<?php endif; ?>>
                                <?php endif; ?>
                                <?php if ( $product['product_image']['url'] ) : ?>
                                    <img src="<?php echo esc_url( $product['product_image']['url'] ); ?>" alt="<?php echo esc_attr( $product['product_title'] ); ?>">
                                <?php endif; ?>
                                <div class="ei-content-bottom<?php if ($product['product_sale_price']) {echo ' eipro-regular-price-active';} ?>">
                                    <div class="eipro-subtitle"><?php echo wp_kses_post( $tab['tab_title'] ); ?></div>
                                    <div class="eipro-title"><?php echo esc_html( $product['product_title'] ); ?></div>
                                    <div class="eipro-product-text-price">
                                    <?php
                                    if ($product['product_text']) {
                                        echo '<div class="eipro-text">' . $product['product_text'] . '</div>';
                                    }
                                    ?>
                                    <?php if ($product['product_regular_price']) { ?>
                                        <div class="eipro-price">
                                            <?php
                                            if ( $product['product_sale_price'] ) {
                                                echo '<span>'. esc_html( $product['product_sale_price'] ) .'</span>';
                                            }
                                            ?>
                                            <span<?php if ( $product['product_sale_price'] ) { echo ' class="eipro-regular-price"'; } ?>>
                                                <?= esc_html( $product['product_regular_price'] ); ?>
                                            </span>
                                        </div>
                                    <?php } ?>
                                    </div>

                                    <?php if ( $product['enable_product_link_icon'] === 'yes' ) : ?>
                                    <div class="ei-cart-btn">
                                        <span>
                                            <?php \Elementor\Icons_Manager::render_icon( $product['product_link_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                                        </span>
                                    </div>
                                    <?php endif; ?>

                                </div>
                                <?php if ( $product['product_link']['url'] ) : ?>
                                </a>
                                <?php endif; ?>
                            </div>
                        </div>

                    <?php endforeach; ?>

                    <div class="ei-more-product">
                        <span><?php echo esc_html(!empty($m_product_btn) ? $m_product_btn : 'More Products'); ?></span>
                    </div>

                </div>


                <?php endif; ?>

            </div>

        <?php endforeach; ?>

        </div>

    </div>


        <?php } else { ?>


        <div class="eipro-tabs-widget">

            <div class="eipro-tabs-wrap e-tabs-sticky">
                <div class="eipro-tabs-sticky">
                    <div>
                        <ul class="eipro-tabs-nav">

                            <?php $i = 0; foreach ( $settings['tabs'] as $index => $tab ) : $i++; ?>

                                <li class="eipro-tabs-nav-item<?php if ( $index === 0 ) : ?> eipro-tab-active<?php endif; ?><?php if(!$tab['tab_thumb']['url']){echo ' no-thumb';} ?>">

                                    <a href="#eipro-tabs-tab<?= $i; ?>" class="eipro-tabs-nav-link">
                                        <?php
                                        if ( $tab['tab_thumb']['url'] ) {
                                            echo '<img src="' . esc_url( $tab['tab_thumb']['url'] ) . '" alt="' . esc_attr( $tab['tab_title'] ) . '">';
                                        }
                                        ?>
                                        <span><?php echo esc_html( $tab['tab_title'] ); ?></span>
                                        <?php
                                            if ( $tab['tab_subtitle'] ) {
                                                echo '<span class="c-desc">' . esc_html( $tab['tab_subtitle'] ) . '</span>';
                                            }
                                        ?>
                                    </a>

                                </li>

                            <?php endforeach; ?>

                            <div class="eipro-d-nav-scroll-icon-left">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="512" height="512"><g id="_01_align_center" data-name="01 align center"><path d="M16.752,23.994,6.879,14.121a3,3,0,0,1,0-4.242L16.746.012,18.16,1.426,8.293,11.293a1,1,0,0,0,0,1.414l9.873,9.873Z"/></g></svg>
                            </div>
                            <div class="eipro-d-nav-scroll-icon-right">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="512" height="512"><g id="_01_align_center" data-name="01 align center"><path d="M7.412,24,6,22.588l9.881-9.881a1,1,0,0,0,0-1.414L6.017,1.431,7.431.017l9.862,9.862a3,3,0,0,1,0,4.242Z"/></g></svg>
                            </div>
                            <div class="eipro-d-nav-graduated-filter-left"></div>
                            <div class="eipro-d-nav-graduated-filter-right"></div>

                        </ul>
                    </div>
                </div>
            </div>

            <div class="eipro-tabs-content">

            <?php $i = 0; foreach ( $settings['tabs'] as $index => $tab ) : $i++; ?>
                <div class="eipro-tabs-tab<?php if ( $index === 0 ) : ?> eipro-tab-active<?php endif; ?>" id="eipro-tabs-tab<?= $i; ?>">

                <?php if ( $tab['product'] ) : ?>

                    <?php
                    $p_number = $settings['products_to_show'];
                    $m_product_btn = $settings['more_products_btn'];
                    ?>

                    <div class="eipro-list" data-load-limit="<?php echo esc_html(!empty($p_number) ? $p_number : 6); ?>">

                    <?php foreach ( $tab['product'] as $product ) : ?>

                        <div class="eipro-list-item<?php if ( $product['enable_product_link_icon'] === 'yes' ) {echo ' ei-with-icon';} ?>">
                            <div>
                                <?php if ( $product['product_link']['url'] ) : ?>
                                <a href="<?php echo esc_url( $product['product_link']['url'] ); ?>"<?php if ( $product['product_link']['is_external'] ) : ?> target="_blank"<?php endif; ?><?php if ( $product['product_link']['nofollow'] ) : ?> rel="nofollow"<?php endif; ?>>
                                <?php endif; ?>
                                <?php if ( $product['product_image']['url'] ) : ?>
                                    <img src="<?php echo esc_url( $product['product_image']['url'] ); ?>" alt="<?php echo esc_attr( $product['product_title'] ); ?>">
                                <?php endif; ?>
                                <div class="ei-content-bottom<?php if ($product['product_sale_price']) {echo ' eipro-regular-price-active';} ?>">
                                    <div class="eipro-subtitle"><?php echo wp_kses_post( $tab['tab_title'] ); ?></div>
                                    <div class="eipro-title"><?php echo esc_html( $product['product_title'] ); ?></div>
                                    <div class="eipro-product-text-price">
                                    <?php
                                    if ($product['product_text']) {
                                        echo '<div class="eipro-text">' . $product['product_text'] . '</div>';
                                    }
                                    ?>
                                    <?php if ($product['product_regular_price']) { ?>
                                        <div class="eipro-price">
                                            <?php
                                            if ( $product['product_sale_price'] ) {
                                                echo '<span>'. esc_html( $product['product_sale_price'] ) .'</span>';
                                            }
                                            ?>
                                            <span<?php if ( $product['product_sale_price'] ) { echo ' class="eipro-regular-price"'; } ?>>
                                                <?= esc_html( $product['product_regular_price'] ); ?>
                                            </span>
                                        </div>
                                    <?php } ?>
                                    </div>

                                    <?php if ( $product['enable_product_link_icon'] === 'yes' ) : ?>
                                    <div class="ei-cart-btn">
                                        <span>
                                            <?php \Elementor\Icons_Manager::render_icon( $product['product_link_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                                        </span>
                                    </div>
                                    <?php endif; ?>

                                </div>
                                <?php if ( $product['product_link']['url'] ) : ?>
                                </a>
                                <?php endif; ?>
                            </div>
                        </div>

                    <?php endforeach; ?>

                    <div class="ei-more-product">
                        <span><?php echo esc_html(!empty($m_product_btn) ? $m_product_btn : 'More Products'); ?></span>
                    </div>

                </div>


                <?php endif; ?>

            </div>

        <?php endforeach; ?>

        </div>

    </div>

    <?php
    }

    if ( defined( 'ELEMENTOR_VERSION' ) && \Elementor\Plugin::$instance->editor->is_edit_mode() ) {
            echo "<script>
                function loadMoreItems(event) {
                    const eiproList = event.currentTarget.parentElement;
                    
                    if (eiproList) {
                      const limit = parseInt(eiproList.getAttribute('data-load-limit'));
                      const items = Array.from(eiproList.querySelectorAll('.eipro-list-item')).filter(item => item.style.display === 'none');
                      const itemsToShow = items.slice(0, limit);

                      itemsToShow.forEach(item => (item.style.display = 'block'));

                      if (items.length <= limit) {
                        const loadMoreButton = eiproList.querySelector('.ei-more-product');
                        if (loadMoreButton) {
                          loadMoreButton.style.display = 'none';
                        }
                      }

                      document.querySelectorAll('.eipro-list').forEach(list => {
                        if (list !== eiproList) {
                          const loadMoreButton = list.querySelector('.ei-more-product');
                          if (loadMoreButton) {
                            const otherItems = Array.from(list.querySelectorAll('.eipro-list-item'));
                            otherItems.forEach((item, index) => (item.style.display = index >= limit ? 'none' : 'block'));
                            loadMoreButton.style.display = otherItems.length <= limit ? 'none' : 'block';
                          }
                        }
                      });
                    }
                  }

                  document.querySelectorAll('.ei-more-product').forEach(button => button.addEventListener('click', loadMoreItems));

                  document.querySelectorAll('.eipro-list').forEach(eiproList => {
                    const limit = parseInt(eiproList.getAttribute('data-load-limit'));
                    const items = Array.from(eiproList.querySelectorAll('.eipro-list-item'));
                    items.forEach((item, index) => (item.style.display = index >= limit ? 'none' : 'block'));

                    if (items.length <= limit) {
                      const loadMoreButton = eiproList.querySelector('.ei-more-product');
                      if (loadMoreButton) {
                        loadMoreButton.style.display = 'none';
                      }
                    }
                });
            </script>";
        }

    }

    protected function _content_template() { ?>

        <# if ( settings.show_first_tab === 'yes' ) { #>
        <div class="eipro-tabs-widget">

            <div class="eipro-tabs-wrap e-tabs-sticky">
                <div class="eipro-tabs-sticky">
                    <div>
                        <ul class="eipro-tabs-nav">

                            <#
                            var show_first_tab_thumb = settings.show_first_tab_thumb.url;
                            var show_first_tab_text = settings.show_first_tab_text ? settings.show_first_tab_text : '<?php esc_html_e( 'All Products', 'eipro-addon' ); ?>';
                            var show_first_tab_description = settings.show_first_tab_description;
                            #>

                            <li class="eipro-tabs-nav-item eipro-tab-active<# if ( !show_first_tab_thumb ) { #> no-thumb<# } #>">

                                <a href="#" class="eipro-tabs-nav-link">
                                    <# if ( show_first_tab_thumb ) { #>
                                    <img src="{{{ show_first_tab_thumb }}}" alt="{{{ show_first_tab_text.alt }}}" />
                                    <# } #>
                                    <span>{{{ show_first_tab_text }}}</span>
                                    <# if ( show_first_tab_description ) { #>
                                        <span class="c-desc">{{{ show_first_tab_description }}}</span>
                                    <# } #>
                                </a>

                            </li>

                            <#
                            _.each( settings.tabs, function( tab, index ) {
                            var tab_thumb = tab.tab_thumb.url;
                            var tab_title = tab.tab_title ? tab.tab_title : '<?php esc_html_e( 'Tab Title', 'eipro-addon' ); ?>';
                            var tab_subtitle = tab.tab_subtitle;
                            #>

                            <li class="eipro-tabs-nav-item<# if ( !tab_thumb ) { #> no-thumb<# } #>">

                                <a href="#" class="eipro-tabs-nav-link">
                                    <# if ( tab_thumb ) { #>
                                    <img src="{{{ tab_thumb }}}" alt="{{{ tab_title.alt }}}" />
                                    <# } #>
                                    <span>{{{ tab_title }}}</span>
                                    <# if ( tab_subtitle ) { #>
                                        <span class="c-desc">{{{ tab_subtitle }}}</span>
                                    <# } #>
                                </a>

                            </li>

                            <# } ); #>

                        </ul>
                    </div>
                </div>
            </div>

            <div class="eipro-tabs-content">

                <div class="eipro-tabs-tab eipro-tab-active">

                    <div class="eipro-list" data-load-limit="<# if ( settings.products_to_show ) { #>{{{ settings.products_to_show }}}<# } else { #>6<# } #>">

                    <#
                    _.each( settings.tabs, function( tab, index ) {
                    #>

                    <# if ( tab.product ) { #>

                        <# _.each( tab.product, function( product, productIndex ) { #>

                            <div class="eipro-list-item <# if ( product.enable_product_link_icon === 'yes' ) { #> ei-with-icon <# } #>">
                                <div>
                                    <# if ( product.product_link.url ) { #>
                                    <a href="{{{ product.product_link }}}">
                                    <# } #>
                                    <# if ( product.product_image.url ) { #>
                                    <img src="{{{ product.product_image.url }}}" alt="{{{ product.product_image.alt }}}" />
                                    <# } #>
                                    <div class="ei-content-bottom <# if ( product.product_sale_price ) { #> eipro-regular-price-active <# } #>">
                                        <div class="eipro-subtitle">{{{ tab.tab_title }}}</div>
                                        <div class="eipro-title">{{{ product.product_title }}}</div>
                                        <div class="eipro-product-text-price">
                                        <# if ( product.product_text ) { #>
                                        <div class="eipro-text">{{{ product.product_text }}}</div>
                                        <# } #>

                                        <# if ( product.product_regular_price ) { #>
                                        <div class="eipro-price">
                                            <# if ( product.product_sale_price ) { #>
                                                <span>{{{ product.product_sale_price }}}</span>
                                            <# } #>
                                            <span class="<# if ( product.product_sale_price ) { #> eipro-regular-price <# } #>">
                                                {{{ product.product_regular_price }}}
                                            </span>
                                        </div>
                                        <# } #>

                                        </div>

                                        <# if ( product.enable_product_link_icon === 'yes' ) { #>
                                            <#
                                            const iconHTML = elementor.helpers.renderIcon( view, product.product_link_icon, { 'aria-hidden': true }, 'i' , 'object' );
                                            #>
                                        <div class="ei-cart-btn">
                                            <span>
                                                {{{ iconHTML.value }}}
                                            </span>
                                        </div>
                                        <# } #>

                                    </div>
                                    <# if ( product.product_link.url ) { #>
                                    </a>
                                    <# } #>
                                </div>
                            </div>

                        <# } ); #>

                <# } #>

                <# } ); #>

                <div class="ei-more-product">
                    <span>
                        <# if ( settings.more_products_btn ) { #>
                            {{{ settings.more_products_btn }}}
                        <# } else { #>
                            More Products
                        <# } #>
                    </span>
                </div>

                </div>

            </div>

                <#
                _.each( settings.tabs, function( tab, index ) {
                #>

                <div class="eipro-tabs-tab">

                    <# if ( tab.product ) { #>

                        <div class="eipro-list" data-load-limit="<# if ( settings.products_to_show ) { #>{{{ settings.products_to_show }}}<# } else { #>6<# } #>">

                        <# _.each( tab.product, function( product, productIndex ) { #>

                            <div class="eipro-list-item <# if ( product.enable_product_link_icon === 'yes' ) { #> ei-with-icon <# } #>">
                                <div>
                                    <# if ( product.product_link.url ) { #>
                                    <a href="{{{ product.product_link }}}">
                                    <# } #>
                                    <# if ( product.product_image.url ) { #>
                                    <img src="{{{ product.product_image.url }}}" alt="{{{ product.product_image.alt }}}" />
                                    <# } #>
                                    <div class="ei-content-bottom <# if ( product.product_sale_price ) { #> eipro-regular-price-active <# } #>">
                                        <div class="eipro-subtitle">{{{ tab.tab_title }}}</div>
                                        <div class="eipro-title">{{{ product.product_title }}}</div>
                                        <div class="eipro-product-text-price">
                                        <# if ( product.product_text ) { #>
                                        <div class="eipro-text">{{{ product.product_text }}}</div>
                                        <# } #>

                                        <# if ( product.product_regular_price ) { #>
                                        <div class="eipro-price">
                                            <# if ( product.product_sale_price ) { #>
                                                <span>{{{ product.product_sale_price }}}</span>
                                            <# } #>
                                            <span class="<# if ( product.product_sale_price ) { #> eipro-regular-price <# } #>">
                                                {{{ product.product_regular_price }}}
                                            </span>
                                        </div>
                                        <# } #>

                                        </div>

                                        <# if ( product.enable_product_link_icon === 'yes' ) { #>
                                            <#
                                            const iconHTML = elementor.helpers.renderIcon( view, product.product_link_icon, { 'aria-hidden': true }, 'i' , 'object' );
                                            #>
                                        <div class="ei-cart-btn">
                                            <span>
                                                {{{ iconHTML.value }}}
                                            </span>
                                        </div>
                                        <# } #>

                                    </div>
                                    <# if ( product.product_link.url ) { #>
                                    </a>
                                    <# } #>
                                </div>
                            </div>

                        <# } ); #>

                        <div class="ei-more-product">
                            <span>
                                <# if ( settings.more_products_btn ) { #>
                                    {{{ settings.more_products_btn }}}
                                <# } else { #>
                                    More Products
                                <# } #>
                            </span>
                        </div>

                    </div>

                <# } #>

            </div>

            <# } ); #>

        </div>

    </div>

    <# } else { #>

        <div class="eipro-tabs-widget">

            <div class="eipro-tabs-wrap e-tabs-sticky">
                <div class="eipro-tabs-sticky">
                    <div>
                        <ul class="eipro-tabs-nav">

                            <#
                            _.each( settings.tabs, function( tab, index ) {
                            var tab_thumb = tab.tab_thumb.url;
                            var tab_title = tab.tab_title ? tab.tab_title : '<?php esc_html_e( 'Tab Title', 'eipro-addon' ); ?>';
                            var tab_subtitle = tab.tab_subtitle;
                            var active_class = index === 0 ? ' eipro-tab-active' : '';
                            #>

                            <li class="eipro-tabs-nav-item{{ active_class }}<# if ( !tab_thumb ) { #> no-thumb<# } #>">

                                <a href="#" class="eipro-tabs-nav-link">
                                    <# if ( tab_thumb ) { #>
                                    <img src="{{{ tab_thumb }}}" alt="{{{ tab_title.alt }}}" />
                                    <# } #>
                                    <span>{{{ tab_title }}}</span>
                                    <# if ( tab_subtitle ) { #>
                                        <span class="c-desc">{{{ tab_subtitle }}}</span>
                                    <# } #>
                                </a>

                            </li>

                            <# } ); #>

                        </ul>
                    </div>
                </div>
            </div>

            <div class="eipro-tabs-content">

                <#
                _.each( settings.tabs, function( tab, index ) {
                var active_class = index === 0 ? ' eipro-tab-active' : '';
                #>

                <div class="eipro-tabs-tab{{ active_class }}">

                    <# if ( tab.product ) { #>

                        <div class="eipro-list" data-load-limit="<# if ( settings.products_to_show ) { #>{{{ settings.products_to_show }}}<# } else { #>6<# } #>">

                        <# _.each( tab.product, function( product, productIndex ) { #>

                            <div class="eipro-list-item <# if ( product.enable_product_link_icon === 'yes' ) { #> ei-with-icon <# } #>">
                                <div>
                                    <# if ( product.product_link.url ) { #>
                                    <a href="{{{ product.product_link }}}">
                                    <# } #>
                                    <# if ( product.product_image.url ) { #>
                                    <img src="{{{ product.product_image.url }}}" alt="{{{ product.product_image.alt }}}" />
                                    <# } #>
                                    <div class="ei-content-bottom <# if ( product.product_sale_price ) { #> eipro-regular-price-active <# } #>">
                                        <div class="eipro-subtitle">{{{ tab.tab_title }}}</div>
                                        <div class="eipro-title">{{{ product.product_title }}}</div>
                                        <div class="eipro-product-text-price">
                                        <# if ( product.product_text ) { #>
                                        <div class="eipro-text">{{{ product.product_text }}}</div>
                                        <# } #>

                                        <# if ( product.product_regular_price ) { #>
                                        <div class="eipro-price">
                                            <# if ( product.product_sale_price ) { #>
                                                <span>{{{ product.product_sale_price }}}</span>
                                            <# } #>
                                            <span class="<# if ( product.product_sale_price ) { #> eipro-regular-price <# } #>">
                                                {{{ product.product_regular_price }}}
                                            </span>
                                        </div>
                                        <# } #>

                                        </div>

                                        <# if ( product.enable_product_link_icon === 'yes' ) { #>
                                            <#
                                            const iconHTML = elementor.helpers.renderIcon( view, product.product_link_icon, { 'aria-hidden': true }, 'i' , 'object' );
                                            #>
                                        <div class="ei-cart-btn">
                                            <span>
                                                {{{ iconHTML.value }}}
                                            </span>
                                        </div>
                                        <# } #>
                
                                    </div>
                                    <# if ( product.product_link.url ) { #>
                                    </a>
                                    <# } #>
                                </div>
                            </div>

                        <# } ); #>

                        <div class="ei-more-product">
                            <span>
                                <# if ( settings.more_products_btn ) { #>
                                    {{{ settings.more_products_btn }}}
                                <# } else { #>
                                    More Products
                                <# } #>
                            </span>
                        </div>

                    </div>

                <# } #>

            </div>

            <# } ); #>

        </div>

    </div>

    <# } #>

    <?php

    if ( defined( 'ELEMENTOR_VERSION' ) && \Elementor\Plugin::$instance->editor->is_edit_mode() ) {
            echo "<script>
                function loadMoreItems(event) {
                    const eiproList = event.currentTarget.parentElement;
                    
                    if (eiproList) {
                      const limit = parseInt(eiproList.getAttribute('data-load-limit'));
                      const items = Array.from(eiproList.querySelectorAll('.eipro-list-item')).filter(item => item.style.display === 'none');
                      const itemsToShow = items.slice(0, limit);

                      itemsToShow.forEach(item => (item.style.display = 'block'));

                      if (items.length <= limit) {
                        const loadMoreButton = eiproList.querySelector('.ei-more-product');
                        if (loadMoreButton) {
                          loadMoreButton.style.display = 'none';
                        }
                      }

                      document.querySelectorAll('.eipro-list').forEach(list => {
                        if (list !== eiproList) {
                          const loadMoreButton = list.querySelector('.ei-more-product');
                          if (loadMoreButton) {
                            const otherItems = Array.from(list.querySelectorAll('.eipro-list-item'));
                            otherItems.forEach((item, index) => (item.style.display = index >= limit ? 'none' : 'block'));
                            loadMoreButton.style.display = otherItems.length <= limit ? 'none' : 'block';
                          }
                        }
                      });
                    }
                  }

                  document.querySelectorAll('.ei-more-product').forEach(button => button.addEventListener('click', loadMoreItems));

                  document.querySelectorAll('.eipro-list').forEach(eiproList => {
                    const limit = parseInt(eiproList.getAttribute('data-load-limit'));
                    const items = Array.from(eiproList.querySelectorAll('.eipro-list-item'));
                    items.forEach((item, index) => (item.style.display = index >= limit ? 'none' : 'block'));

                    if (items.length <= limit) {
                      const loadMoreButton = eiproList.querySelector('.ei-more-product');
                      if (loadMoreButton) {
                        loadMoreButton.style.display = 'none';
                      }
                    }
                });
            </script>";
        }

    }

}
