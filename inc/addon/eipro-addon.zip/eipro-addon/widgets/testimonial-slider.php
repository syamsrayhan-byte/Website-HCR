<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

class Elementor_Testimonial_Slider_Widget extends \Elementor\Widget_Base {

    public function get_name() {
        return 'eipro-testimonial';
    }

    public function get_title() {
        return __( 'Testimonial Slider - eiPro', 'eipro-addon' );
    }

    public function get_icon() {
        return 'eicon-testimonial-carousel';
    }

    public function get_categories() {
        return [ 'general' ];
    }

    public function get_keywords() {
        return [ 'testimonial', 'testimonials', 'slider' ];
    }


    protected function _register_controls() {

        $this->start_controls_section(
            'section_tab_testimonials',
            [
                'label' => esc_html__( 'Testimonial', 'eipro-addon' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'testi_content',
            [
                'label' => esc_html__( 'Content', 'eipro-addon' ),
                'type' => \Elementor\Controls_Manager::WYSIWYG,
                'placeholder' => esc_html__( 'Description', 'eipro-addon' ),
                'default' => esc_html__( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.', 'eipro-addon' ),
                'label_block' => true,
                'dynamic' => [
                    'active' => true,
                ],
            ]
        );

        $repeater->add_control(
            'testi_image',
            [
                'label' => esc_html__( 'Choose Image', 'eipro-addon' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
                'label_block' => true,
                'dynamic' => [
                    'active' => true,
                ],
            ]
        );

        $repeater->add_control(
            'testi_name',
            [
                'label' => esc_html__( 'Name', 'eipro-addon' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'placeholder' => esc_html__( 'John Doe', 'eipro-addon' ),
                'default' => esc_html__( 'John Doe', 'eipro-addon' ),
                'label_block' => true,
                'dynamic' => [
                    'active' => true,
                ],
            ]
        );

        $repeater->add_control(
            'testi_title',
            [
                'label' => esc_html__( 'Title', 'eipro-addon' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'placeholder' => esc_html__( 'Designer', 'eipro-addon' ),
                'default' => esc_html__( 'Designer', 'eipro-addon' ),
                'label_block' => true,
                'dynamic' => [
                    'active' => true,
                ],
            ]
        );

        $this->add_control(
            'testimonials',
            [
                'label' => esc_html__( 'Testimonials', 'eipro-addon' ),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),           /* Use our repeater */
                'default' => [
                    [
                        'testi_content' => esc_html__( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.', 'eipro-addon' ),
                        'testi_name' => esc_html__( 'John Doe', 'eipro-addon' ),
                        'testi_title' => esc_html__( 'Designer', 'eipro-addon' ),
                    ],
                    [
                        'testi_content' => esc_html__( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.', 'eipro-addon' ),
                        'testi_name' => esc_html__( 'John Doe', 'eipro-addon' ),
                        'testi_title' => esc_html__( 'Designer', 'eipro-addon' ),
                    ],
                    [
                        'testi_content' => esc_html__( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.', 'eipro-addon' ),
                        'testi_name' => esc_html__( 'John Doe', 'eipro-addon' ),
                        'testi_title' => esc_html__( 'Designer', 'eipro-addon' ),
                    ],
                ],
                'title_field' => '{{{ testi_name }}}',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_tab_options',
            [
                'label' => esc_html__( 'Additional Options', 'eipro-addon' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'slides_to_show',
            [
                'label' => __( 'Slides to Show', 'eipro-addon' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'min' => 1,
                'max' => 10,
                'default' => 3,
            ]
        );

        $this->add_control(
            'slides_to_scroll',
            [
                'label' => __( 'Slides to Scroll', 'eipro-addon' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'min' => 1,
                'max' => 10,
                'default' => 1,
            ]
        );

        $this->add_control(
            'infinite_loop',
            [
                'label' => __( 'Infinite Loop', 'eipro-addon' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'true',
                'options' => [
                    'false'  => esc_html__( 'No', 'eipro-addon' ),
                    'true' => esc_html__( 'Yes', 'eipro-addon' ),
                ],
            ]
        );

        $this->add_control(
            'slides_autoplay',
            [
                'label' => __( 'Autoplay', 'eipro-addon' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'true',
                'options' => [
                    'false'  => esc_html__( 'No', 'eipro-addon' ),
                    'true' => esc_html__( 'Yes', 'eipro-addon' ),
                ],
            ]
        );

        $this->add_control(
            'slides_navigation',
            [
                'label' => __( 'Navigation', 'eipro-addon' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'true',
                'options' => [
                    'false'  => esc_html__( 'None', 'eipro-addon' ),
                    'true' => esc_html__( 'Dots', 'eipro-addon' ),
                ],
            ]
        );

        $this->end_controls_section();

    }

    protected function render() {

        // Get the settings
        $settings = $this->get_settings_for_display();

        // Set up the slider
        $slides = '';
        foreach ( $settings['testimonials'] as $testi ) {
            $slides .= '<div><div class="eipro-testimonial-wrap">
            <div class="eipro-testimonial-rating">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="17" viewBox="0 0 18 17" fill="none"><path d="M6.31753 5.00252L8.52542 0.555149C8.80881 -0.0157788 9.6277 -0.0157788 9.91109 0.555149L12.119 5.00252L17.0565 5.72009C17.69 5.81216 17.9425 6.58644 17.4839 7.03056L13.9117 10.49L14.7547 15.3771C14.863 16.0048 14.2004 16.4833 13.6336 16.1869L9.21826 13.8782L4.80291 16.1869C4.23607 16.4833 3.57349 16.0048 3.68174 15.3771L4.52477 10.49L0.952651 7.03056C0.494008 6.58644 0.7465 5.81216 1.38 5.72009L6.31753 5.00252Z" fill="#FFB422"/></svg><svg xmlns="http://www.w3.org/2000/svg" width="18" height="17" viewBox="0 0 18 17" fill="none"><path d="M6.31753 5.00252L8.52542 0.555149C8.80881 -0.0157788 9.6277 -0.0157788 9.91109 0.555149L12.119 5.00252L17.0565 5.72009C17.69 5.81216 17.9425 6.58644 17.4839 7.03056L13.9117 10.49L14.7547 15.3771C14.863 16.0048 14.2004 16.4833 13.6336 16.1869L9.21826 13.8782L4.80291 16.1869C4.23607 16.4833 3.57349 16.0048 3.68174 15.3771L4.52477 10.49L0.952651 7.03056C0.494008 6.58644 0.7465 5.81216 1.38 5.72009L6.31753 5.00252Z" fill="#FFB422"/></svg><svg xmlns="http://www.w3.org/2000/svg" width="18" height="17" viewBox="0 0 18 17" fill="none"><path d="M6.31753 5.00252L8.52542 0.555149C8.80881 -0.0157788 9.6277 -0.0157788 9.91109 0.555149L12.119 5.00252L17.0565 5.72009C17.69 5.81216 17.9425 6.58644 17.4839 7.03056L13.9117 10.49L14.7547 15.3771C14.863 16.0048 14.2004 16.4833 13.6336 16.1869L9.21826 13.8782L4.80291 16.1869C4.23607 16.4833 3.57349 16.0048 3.68174 15.3771L4.52477 10.49L0.952651 7.03056C0.494008 6.58644 0.7465 5.81216 1.38 5.72009L6.31753 5.00252Z" fill="#FFB422"/></svg><svg xmlns="http://www.w3.org/2000/svg" width="18" height="17" viewBox="0 0 18 17" fill="none"><path d="M6.31753 5.00252L8.52542 0.555149C8.80881 -0.0157788 9.6277 -0.0157788 9.91109 0.555149L12.119 5.00252L17.0565 5.72009C17.69 5.81216 17.9425 6.58644 17.4839 7.03056L13.9117 10.49L14.7547 15.3771C14.863 16.0048 14.2004 16.4833 13.6336 16.1869L9.21826 13.8782L4.80291 16.1869C4.23607 16.4833 3.57349 16.0048 3.68174 15.3771L4.52477 10.49L0.952651 7.03056C0.494008 6.58644 0.7465 5.81216 1.38 5.72009L6.31753 5.00252Z" fill="#FFB422"/></svg><svg xmlns="http://www.w3.org/2000/svg" width="18" height="17" viewBox="0 0 18 17" fill="none"><path d="M6.31753 5.00252L8.52542 0.555149C8.80881 -0.0157788 9.6277 -0.0157788 9.91109 0.555149L12.119 5.00252L17.0565 5.72009C17.69 5.81216 17.9425 6.58644 17.4839 7.03056L13.9117 10.49L14.7547 15.3771C14.863 16.0048 14.2004 16.4833 13.6336 16.1869L9.21826 13.8782L4.80291 16.1869C4.23607 16.4833 3.57349 16.0048 3.68174 15.3771L4.52477 10.49L0.952651 7.03056C0.494008 6.58644 0.7465 5.81216 1.38 5.72009L6.31753 5.00252Z" fill="#FFB422"/></svg>
            </div>
            <div class="eipro-testimonial-content">
                ' . $testi['testi_content'] . '
            </div>
            <div class="eipro-testimonial-person">
                <div>
                    <div class="eipro-testimonial-person-thumb"><img src="' . $testi['testi_image']['url'] . '" alt="' . esc_attr( $testi['testi_name'] ) . '"></div>
                    <div class="eipro-testimonial-person-info">
                        <span class="eipro-testimonial-person-info-title">
                            ' . $testi['testi_name'] . '
                        </span>
                        <span class="eipro-testimonial-person-info-subtitle">
                            ' . $testi['testi_title'] . '
                        </span>
                    </div>
                </div>
            </div>
            </div></div>';
        }

        // Output the slider
        ?>
        <div class="eipro-testimonial" data-slick='{"dots": <?= $settings['slides_navigation']; ?>, "slidesToShow": <?= $settings['slides_to_show']; ?>, "slidesToScroll": <?= $settings['slides_to_scroll']; ?>, "infinite": <?= $settings['infinite_loop']; ?>, "autoplay": <?= $settings['slides_autoplay']; ?>}'><?= $slides; ?></div>
        <?php

        if ( defined( 'ELEMENTOR_VERSION' ) && \Elementor\Plugin::$instance->editor->is_edit_mode() ) {
            echo '<script>
                jQuery(document).ready(function(){
                
                jQuery(".eipro-testimonial").slick({
                  arrows: false,
                  autoplaySpeed: 3300,
                  speed: 800,
                  responsive: [
                    {
                      breakpoint: 1025,
                      settings: {
                        slidesToShow: 2,
                        slidesToScroll: 1
                      }
                    },
                    {
                      breakpoint: 767,
                      settings: {
                        slidesToShow: 1,
                        slidesToScroll: 1
                      }
                    }
                  ]
              });

            });
            </script>';
        }

    }

    protected function _content_template() {
        ?>

        <div class="eipro-testimonial" data-slick='{"dots": {{{ settings.slides_navigation }}}, "slidesToShow": {{{ settings.slides_to_show }}}, "slidesToScroll": {{{ settings.slides_to_scroll }}}, "infinite": {{{ settings.infinite_loop }}}, "autoplay": {{{ settings.slides_autoplay }}} }'>
        <# _.each( settings.testimonials, function( testi ) { #>
            <div>
                <div class="eipro-testimonial-wrap">
                    <div class="eipro-testimonial-rating">
                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="17" viewBox="0 0 18 17" fill="none"><path d="M6.31753 5.00252L8.52542 0.555149C8.80881 -0.0157788 9.6277 -0.0157788 9.91109 0.555149L12.119 5.00252L17.0565 5.72009C17.69 5.81216 17.9425 6.58644 17.4839 7.03056L13.9117 10.49L14.7547 15.3771C14.863 16.0048 14.2004 16.4833 13.6336 16.1869L9.21826 13.8782L4.80291 16.1869C4.23607 16.4833 3.57349 16.0048 3.68174 15.3771L4.52477 10.49L0.952651 7.03056C0.494008 6.58644 0.7465 5.81216 1.38 5.72009L6.31753 5.00252Z" fill="#FFB422"/></svg><svg xmlns="http://www.w3.org/2000/svg" width="18" height="17" viewBox="0 0 18 17" fill="none"><path d="M6.31753 5.00252L8.52542 0.555149C8.80881 -0.0157788 9.6277 -0.0157788 9.91109 0.555149L12.119 5.00252L17.0565 5.72009C17.69 5.81216 17.9425 6.58644 17.4839 7.03056L13.9117 10.49L14.7547 15.3771C14.863 16.0048 14.2004 16.4833 13.6336 16.1869L9.21826 13.8782L4.80291 16.1869C4.23607 16.4833 3.57349 16.0048 3.68174 15.3771L4.52477 10.49L0.952651 7.03056C0.494008 6.58644 0.7465 5.81216 1.38 5.72009L6.31753 5.00252Z" fill="#FFB422"/></svg><svg xmlns="http://www.w3.org/2000/svg" width="18" height="17" viewBox="0 0 18 17" fill="none"><path d="M6.31753 5.00252L8.52542 0.555149C8.80881 -0.0157788 9.6277 -0.0157788 9.91109 0.555149L12.119 5.00252L17.0565 5.72009C17.69 5.81216 17.9425 6.58644 17.4839 7.03056L13.9117 10.49L14.7547 15.3771C14.863 16.0048 14.2004 16.4833 13.6336 16.1869L9.21826 13.8782L4.80291 16.1869C4.23607 16.4833 3.57349 16.0048 3.68174 15.3771L4.52477 10.49L0.952651 7.03056C0.494008 6.58644 0.7465 5.81216 1.38 5.72009L6.31753 5.00252Z" fill="#FFB422"/></svg><svg xmlns="http://www.w3.org/2000/svg" width="18" height="17" viewBox="0 0 18 17" fill="none"><path d="M6.31753 5.00252L8.52542 0.555149C8.80881 -0.0157788 9.6277 -0.0157788 9.91109 0.555149L12.119 5.00252L17.0565 5.72009C17.69 5.81216 17.9425 6.58644 17.4839 7.03056L13.9117 10.49L14.7547 15.3771C14.863 16.0048 14.2004 16.4833 13.6336 16.1869L9.21826 13.8782L4.80291 16.1869C4.23607 16.4833 3.57349 16.0048 3.68174 15.3771L4.52477 10.49L0.952651 7.03056C0.494008 6.58644 0.7465 5.81216 1.38 5.72009L6.31753 5.00252Z" fill="#FFB422"/></svg><svg xmlns="http://www.w3.org/2000/svg" width="18" height="17" viewBox="0 0 18 17" fill="none"><path d="M6.31753 5.00252L8.52542 0.555149C8.80881 -0.0157788 9.6277 -0.0157788 9.91109 0.555149L12.119 5.00252L17.0565 5.72009C17.69 5.81216 17.9425 6.58644 17.4839 7.03056L13.9117 10.49L14.7547 15.3771C14.863 16.0048 14.2004 16.4833 13.6336 16.1869L9.21826 13.8782L4.80291 16.1869C4.23607 16.4833 3.57349 16.0048 3.68174 15.3771L4.52477 10.49L0.952651 7.03056C0.494008 6.58644 0.7465 5.81216 1.38 5.72009L6.31753 5.00252Z" fill="#FFB422"/></svg>
                    </div>
                    <div class="eipro-testimonial-content">
                        {{{ testi.testi_content }}}
                    </div>
                    <div class="eipro-testimonial-person">
                        <div>
                            <div class="eipro-testimonial-person-thumb"><img src="{{{ testi.testi_image.url }}}" alt="{{{ testi.testi_image.alt }}}" /></div>
                            <div class="eipro-testimonial-person-info">
                                <span class="eipro-testimonial-person-info-title">
                                    {{{ testi.testi_name }}}
                                </span>
                                <span class="eipro-testimonial-person-info-subtitle">
                                    {{{ testi.testi_title }}}
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <# } ); #>
        </div>

        <?php

        if ( defined( 'ELEMENTOR_VERSION' ) && \Elementor\Plugin::$instance->editor->is_edit_mode() ) {
            echo '<script>
                jQuery(document).ready(function(){
                
                jQuery(".eipro-testimonial").slick({
                  arrows: false,
                  autoplaySpeed: 3300,
                  speed: 800
              });

            });
            </script>';
        }

    }


}